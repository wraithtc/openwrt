#include "basic.h"

//��ȡ���޸�����

void proc_rsacfg_encrypt(cJSON *jsonValue,cJSON *jsonOut)
{
    DEBUG_PRINTF("===[%s]===\n",__func__);
    char *str=NULL;
    str=cJSON_GetObjectItem(jsonValue, "password")?cJSON_GetObjectItem(jsonValue, "password")->valuestring:"";
    unsigned char *result=NULL;
    int result_len=0;
    result = (unsigned char *)my_encrypt(str, RSA_PUBLIC_KEY_FILE,&result_len);
    if(result == NULL)
    {
        cJSON_AddItemToObject(jsonOut, "code", cJSON_CreateNumber(1));	
	    cJSON_AddItemToObject(jsonOut, "msg", cJSON_CreateString("encrypt fail"));
    }
    else
    {
        char base64[2048]={0};
        base64_encode(result, base64, result_len);
        DEBUG_PRINTF("====base64: %s  ====\n", base64);
        
        cJSON_AddItemToObject(jsonOut, "result", cJSON_CreateString(base64));
        cJSON_AddItemToObject(jsonOut, "code", cJSON_CreateNumber(0));	
	    cJSON_AddItemToObject(jsonOut, "msg", cJSON_CreateString("success"));
    }
}


//void proc_rsacfg_decrypt(cJSON *jsonValue,cJSON *jsonOut)
void check_gui_password(cJSON *jsonValue,cJSON *jsonOut)
{
    DEBUG_PRINTF("====[%s]=====\n",__func__);
    cJSON *obj = NULL;
	obj = cJSON_CreateObject();
    cJSON_AddItemToObject(jsonOut, "data", obj);
    char password[256]={0};
    strncpy(password,cJSON_GetObjectItem(jsonValue, "password")?cJSON_GetObjectItem(jsonValue, "password")->valuestring:"",sizeof(password));

    char username[64]={0};
    strncpy(username,cJSON_GetObjectItem(jsonValue, "username")?cJSON_GetObjectItem(jsonValue, "username")->valuestring:"",sizeof(username));

    if( (strlen(password)==0) || (strlen(username)==0) )
    {
        global_weberrorcode = ERR_PARAMETER_MISS;
        return;
    }
    
#if 0
    char *target=NULL;
    target = cJSON_GetObjectItem(jsonValue, "target")?cJSON_GetObjectItem(jsonValue, "target")->valuestring:"";
#endif

    DEBUG_PRINTF("===[%s]===str: %s ===\n",__func__,password);
    unsigned char bindata[2048]={0};
    base64_decode(password, bindata);
    
    char *result=NULL;
    result=(char *)my_decrypt(bindata, RSA_PRIVATE_KEY_FILE);
    if(result == NULL)
    {
        global_weberrorcode= ERR_DECRY_FAIL;
        return;
        #if 0
        cJSON_AddItemToObject(jsonOut, "code", cJSON_CreateNumber(1));	
	    cJSON_AddItemToObject(jsonOut, "msg", cJSON_CreateString("password decry fail"));
        #endif 
    }

    int ret=0;
    ret=CheckGuiPassword(result);

    if(ret !=0)
    {
        global_weberrorcode=ERR_PASSWORD_NOTMATCH;

    }
    else
    {
        char tokenid[MAX_TOKENID_LEN]={0};
        generatortokenid(tokenid);
        setTokenId(tokenid);
        cJSON_AddItemToObject(obj, "tokenid", cJSON_CreateString(tokenid));
     
    }     
}

//void proc_rsacfg_decrypt(cJSON *jsonValue,cJSON *jsonOut)
void reset_gui_password(cJSON *jsonValue,cJSON *jsonOut)
{
    DEBUG_PRINTF("====[%s]=====\n",__func__);
    cJSON *obj = NULL;
	obj = cJSON_CreateObject();
    cJSON_AddItemToObject(jsonOut, "data", obj);
    char password[256]={0};
    strncpy(password,cJSON_GetObjectItem(jsonValue, "password")?cJSON_GetObjectItem(jsonValue, "password")->valuestring:"",sizeof(password));

    char username[64]={0};
    strncpy(username,cJSON_GetObjectItem(jsonValue, "username")?cJSON_GetObjectItem(jsonValue, "username")->valuestring:"",sizeof(username));
    

    DEBUG_PRINTF("===[%s]===str: %s ===\n",__func__,password);
    unsigned char bindata[2048]={0};
    base64_decode(password, bindata);
    
    char *result=NULL;
    result=(char *)my_decrypt(bindata, RSA_PRIVATE_KEY_FILE);
    if(result == NULL)
    {
        global_weberrorcode=ERR_DECRY_FAIL;
        return;
    }
    else
    {
        //��set֮ǰ��Ҫ����������Ƿ�ƥ��
        int ret=0;
        char oldPassworld[16]={0};
        ret=GetGuiPassword(oldPassworld);
        //�����ǰϵͳ����Ϊ�ջ򲻿�ȡʱ�������������������������Ӧ�÷����ڵ�һ������
        if( (ret!=0) || (strlen(oldPassworld)==0) )
        {
            DEBUG_PRINTF("===[%s]====cant get current password from system, so ignore password match===\n",__func__);
        }
        else
        {
            char oldpassword[256]={0};
            strncpy(oldpassword,cJSON_GetObjectItem(jsonValue, "oldpassword")?cJSON_GetObjectItem(jsonValue, "oldpassword")->valuestring:"",sizeof(oldpassword));
            unsigned char old_bindata[2048]={0};
            base64_decode(oldpassword, old_bindata);
            char *old_result=NULL;
            old_result=(char *)my_decrypt(old_bindata, RSA_PRIVATE_KEY_FILE);
            if(old_result==NULL)
            {
                global_weberrorcode=ERR_DECRY_FAIL;
                return;
            }
            ret=CheckGuiPassword(old_result);
            if(ret !=0)
            {
                global_weberrorcode=ERR_PASSWORD_NOTMATCH;
                return;
            }
        }
        
        ret=SetGuiPassword(result);
        if(ret !=0)
        {
            global_weberrorcode= ERR_INTERNALLOGIC_WRONG;
            return;
        }
        else
        {   
            char tokenid[200]={0};
            generatortokenid(tokenid);
            setTokenId(tokenid);
            cJSON_AddItemToObject(obj, "tokenid", cJSON_CreateString(tokenid));
        }
      
    }
}

void proc_firstconfigure_set(cJSON *jsonValue,cJSON *jsonOut)
{
    DEBUG_PRINTF("====[%s]=====\n",__func__);

    //����wifi 
    proc_wireless_set(jsonValue,jsonOut);
    
    cJSON *obj = NULL;
	obj = cJSON_CreateObject();
    cJSON_AddItemToObject(jsonOut, "data", obj);
    char password[256]={0};
    strncpy(password,cJSON_GetObjectItem(jsonValue, "password")?cJSON_GetObjectItem(jsonValue, "password")->valuestring:"",sizeof(password));

    DEBUG_PRINTF("===[%s]===str: %s ===\n",__func__,password);
    unsigned char bindata[2048]={0};
    base64_decode(password, bindata);
    
    char *result=NULL;
    result=(char *)my_decrypt(bindata, RSA_PRIVATE_KEY_FILE);
    if(result == NULL)
    {
        global_weberrorcode=ERR_DECRY_FAIL;
    }
    else
    {
        //��set֮ǰ��Ҫ����������Ƿ�ƥ��
        int ret=0;
           
        ret=SetGuiPassword(result);
        if(ret !=0)
        {
           global_weberrorcode=ERR_INTERNALLOGIC_WRONG;
        }
        else
        {   
            char tokenid[200]={0};
            generatortokenid(tokenid);
            setTokenId(tokenid);
            cJSON_AddItemToObject(obj, "tokenid", cJSON_CreateString(tokenid));

            //����ϵͳ����Ϊ1
            SetSystemConfigured(1);

        }
     
    }
    
}