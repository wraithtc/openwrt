#include "basic.h"

void proc_wifi_set(cJSON *jsonValue,cJSON *jsonOut)
{
	int ret=0;
	WifiConfig  stConfig = {0};
	int index=0;
	unsigned char bindata[2048]={0};
	char *result=NULL;
	char *password;
	
	//2.4g
	strcpy(stConfig.Disabled1, (cJSON_GetObjectItem(jsonValue, "disabled1")?cJSON_GetObjectItem(jsonValue, "disabled1")->valuestring:""));
	strcpy(stConfig.Ssid1, (cJSON_GetObjectItem(jsonValue, "ssid1")?cJSON_GetObjectItem(jsonValue, "ssid1")->valuestring:""));
	password =cJSON_GetObjectItem(jsonValue, "key1")?cJSON_GetObjectItem(jsonValue, "key1")->valuestring:"";
	base64_decode(password, bindata);
	result=(char *)my_decrypt(bindata, RSA_PRIVATE_KEY_FILE); 
	if(result == NULL)
	{
		global_weberrorcode=ERR_DECRY_FAIL;
		return;
	}
	strcpy(stConfig.Key1, result);
	strcpy(stConfig.Hidden1, (cJSON_GetObjectItem(jsonValue, "hidden1")?cJSON_GetObjectItem(jsonValue, "hidden1")->valuestring:""));
	
	//5g
	strcpy(stConfig.Disabled2, (cJSON_GetObjectItem(jsonValue, "disabled2")?cJSON_GetObjectItem(jsonValue, "disabled2")->valuestring:""));
	strcpy(stConfig.Ssid2, (cJSON_GetObjectItem(jsonValue, "ssid2")?cJSON_GetObjectItem(jsonValue, "ssid2")->valuestring:""));
	password =cJSON_GetObjectItem(jsonValue, "key2")?cJSON_GetObjectItem(jsonValue, "key2")->valuestring:"";
	memset(bindata, 0, 2048);
	base64_decode(password, bindata);    
	result=(char *)my_decrypt(bindata, RSA_PRIVATE_KEY_FILE); 
	if(result == NULL)
	{
		global_weberrorcode=ERR_DECRY_FAIL;
		return;
	}
	strcpy(stConfig.Key2, result);
	strcpy(stConfig.Hidden2, (cJSON_GetObjectItem(jsonValue, "hidden2")?cJSON_GetObjectItem(jsonValue, "hidden2")->valuestring:""));

	ret = setWifiConfig(&stConfig);
	if(ret !=0)
	{
		global_weberrorcode=ERR_INTERNALLOGIC_WRONG;      
	}
}

void proc_wifi_get(cJSON *jsonValue,cJSON *jsonOut)
{
	cJSON *array = NULL;
	cJSON *obj = NULL;
	int ret=0;
	int index=0;
	int tablenum=0;
	WifiConfig  config;
	unsigned char bindata[2048]={0};    
	
	getWifiConfig(&config);
	
	cJSON_AddItemToObject(jsonOut,"data", obj=cJSON_CreateObject());
    
	cJSON_AddStringToObject(obj,"disabled1",config.Disabled1[0] == 0?config.Disabled1:"0");
	cJSON_AddStringToObject(obj,"ssid1",config.Ssid1);
	base64_decode(config.Key1, bindata);
	cJSON_AddStringToObject(obj,"key1",bindata);
	cJSON_AddStringToObject(obj,"hidden1",config.Hidden1[0]== 0?config.Hidden1:"0");
	cJSON_AddStringToObject(obj,"disabled2",config.Disabled2[0] == 0?config.Disabled2:"0");
	cJSON_AddStringToObject(obj,"ssid2",config.Ssid2);
	memset(bindata, 0 ,2048);
	base64_decode(config.Key2, bindata);
	cJSON_AddStringToObject(obj,"key2",bindata);
	cJSON_AddStringToObject(obj,"hidden2",config.Hidden2[0]== 0?config.Hidden2:"0");
}

void proc_wireless_set(cJSON *jsonValue,cJSON *jsonOut)
{
    DEBUG_PRINTF("===[%s]====\n",__func__);
    int ret=0;
    WifiDevice stWifiDevice = {0};
	WifiIface  stWifiIface = {0};
    int index=0;
    index = cJSON_GetObjectItem(jsonValue, "index")?cJSON_GetObjectItem(jsonValue, "index")->valueint:0;
	strcpy(stWifiDevice.WifiDevice, (cJSON_GetObjectItem(jsonValue, "wifi-device")?cJSON_GetObjectItem(jsonValue, "wifi-device")->valuestring:""));
	strcpy(stWifiDevice.Type, (cJSON_GetObjectItem(jsonValue, "type")?cJSON_GetObjectItem(jsonValue, "type")->valuestring:""));
	strcpy(stWifiDevice.Country, (cJSON_GetObjectItem(jsonValue, "country")?cJSON_GetObjectItem(jsonValue, "country")->valuestring:""));
	strcpy(stWifiDevice.Channel, (cJSON_GetObjectItem(jsonValue, "channel")?cJSON_GetObjectItem(jsonValue, "channel")->valuestring:""));
	strcpy(stWifiDevice.Disabled, (cJSON_GetObjectItem(jsonValue, "disabled")?cJSON_GetObjectItem(jsonValue, "disabled")->valuestring:""));
	strcpy(stWifiIface.Device, (cJSON_GetObjectItem(jsonValue, "device")?cJSON_GetObjectItem(jsonValue, "device")->valuestring:""));
	strcpy(stWifiIface.Network, (cJSON_GetObjectItem(jsonValue, "network")?cJSON_GetObjectItem(jsonValue, "network")->valuestring:""));
	strcpy(stWifiIface.Mode, (cJSON_GetObjectItem(jsonValue, "mode")?cJSON_GetObjectItem(jsonValue, "mode")->valuestring:""));
	strcpy(stWifiIface.Ssid, (cJSON_GetObjectItem(jsonValue, "ssid")?cJSON_GetObjectItem(jsonValue, "ssid")->valuestring:""));
	strcpy(stWifiIface.Encryption, (cJSON_GetObjectItem(jsonValue, "encryption")?cJSON_GetObjectItem(jsonValue, "encryption")->valuestring:""));
    char *password=NULL;
    password =cJSON_GetObjectItem(jsonValue, "key")?cJSON_GetObjectItem(jsonValue, "key")->valuestring:"";

    DEBUG_PRINTF("===[%s]===str: %s ===\n",__func__,password);
    unsigned char bindata[2048]={0};
    base64_decode(password, bindata);
    
    char *result=NULL;
    result=(char *)my_decrypt(bindata, RSA_PRIVATE_KEY_FILE); 
    if(result == NULL)
    {
        global_weberrorcode=ERR_DECRY_FAIL;
        return;
    }
    strcpy(stWifiIface.Key, result);
    //strcpy(stWifiIface.Key, (cJSON_GetObjectItem(jsonValue, "key")?cJSON_GetObjectItem(jsonValue, "key")->valuestring:""));
	strcpy(stWifiIface.Wds, (cJSON_GetObjectItem(jsonValue, "wds")?cJSON_GetObjectItem(jsonValue, "wds")->valuestring:""));
	strcpy(stWifiIface.Ifname, (cJSON_GetObjectItem(jsonValue, "ifname")?cJSON_GetObjectItem(jsonValue, "ifname")->valuestring:""));
	strcpy(stWifiIface.Hidden, (cJSON_GetObjectItem(jsonValue, "hidden")?cJSON_GetObjectItem(jsonValue, "hidden")->valuestring:""));
	ret=WifiUciEdit(&stWifiDevice, &stWifiIface, index);

    if(ret !=0)
    {
        global_weberrorcode=ERR_INTERNALLOGIC_WRONG;      
    }
   
}


void proc_wireless_get(cJSON *jsonValue,cJSON *jsonOut)
{
    DEBUG_PRINTF("===%s==%d=\n",__func__,__LINE__);
	cJSON *array = NULL;
	cJSON *obj = NULL;
    int ret=0;
    int index=0;
    int tablenum=0;
    WifiIface  *pstWifiIface = NULL;
    pstWifiIface = WifiInfoGet(&tablenum);

	cJSON_AddItemToObject(jsonOut,"list",array=cJSON_CreateArray());
    printf("===%s==%d=\n",__func__,__LINE__);fflush(stdout);
	for(index =0; index < tablenum; index++)
	{
        printf("===%s==%d=\n",__func__,__LINE__);fflush(stdout);
	    cJSON_AddItemToArray(array,obj=cJSON_CreateObject());
		cJSON_AddItemToObject(obj,"mode",cJSON_CreateString(pstWifiIface[index].Mode));
		cJSON_AddItemToObject(obj,"ssid",cJSON_CreateString(pstWifiIface[index].Ssid));
		cJSON_AddItemToObject(obj,"encryption",cJSON_CreateString(pstWifiIface[index].Encryption));
		cJSON_AddItemToObject(obj,"key",cJSON_CreateString(pstWifiIface[index].Key));
        printf("===%s==%d=\n",__func__,__LINE__);fflush(stdout);
		
	}
	if(pstWifiIface)
        free(pstWifiIface);
    
    cJSON_AddItemToObject(jsonOut, "code", cJSON_CreateNumber(0));	
	cJSON_AddItemToObject(jsonOut, "msg", cJSON_CreateString("success"));
}

void proc_wireless(cJSON *json_value)
{
	WifiDevice stWifiDevice = {0};
	WifiIface  stWifiIface = {0};
	cJSON *array = NULL;
	cJSON *obj = NULL;
	WifiIface  *pstWifiIface = NULL;
	char device[64] = {0};
	int index = 0;
	int tablenum = 0; 	
	int method;
	switch (method)
	{
		case WIFIADD:
			strcpy(stWifiDevice.WifiDevice, (cJSON_GetObjectItem(json_value, "wifi-device")?cJSON_GetObjectItem(json_value, "wifi-device")->valuestring:""));
			strcpy(stWifiDevice.Type, (cJSON_GetObjectItem(json_value, "type")?cJSON_GetObjectItem(json_value, "type")->valuestring:""));
			strcpy(stWifiDevice.Country, (cJSON_GetObjectItem(json_value, "country")?cJSON_GetObjectItem(json_value, "country")->valuestring:""));
			strcpy(stWifiDevice.Channel, (cJSON_GetObjectItem(json_value, "channel")?cJSON_GetObjectItem(json_value, "channel")->valuestring:""));
			strcpy(stWifiDevice.Disabled, (cJSON_GetObjectItem(json_value, "disabled")?cJSON_GetObjectItem(json_value, "disabled")->valuestring:""));
			strcpy(stWifiIface.Device, (cJSON_GetObjectItem(json_value, "device")?cJSON_GetObjectItem(json_value, "device")->valuestring:""));
			strcpy(stWifiIface.Network, (cJSON_GetObjectItem(json_value, "network")?cJSON_GetObjectItem(json_value, "network")->valuestring:""));
			strcpy(stWifiIface.Mode, (cJSON_GetObjectItem(json_value, "mode")?cJSON_GetObjectItem(json_value, "mode")->valuestring:""));
			strcpy(stWifiIface.Ssid, (cJSON_GetObjectItem(json_value, "ssid")?cJSON_GetObjectItem(json_value, "ssid")->valuestring:""));
			strcpy(stWifiIface.Encryption, (cJSON_GetObjectItem(json_value, "encryption")?cJSON_GetObjectItem(json_value, "encryption")->valuestring:""));
			strcpy(stWifiIface.Key, (cJSON_GetObjectItem(json_value, "key")?cJSON_GetObjectItem(json_value, "key")->valuestring:""));
			strcpy(stWifiIface.Wds, (cJSON_GetObjectItem(json_value, "wds")?cJSON_GetObjectItem(json_value, "wds")->valuestring:""));
			strcpy(stWifiIface.Ifname, (cJSON_GetObjectItem(json_value, "ifname")?cJSON_GetObjectItem(json_value, "ifname")->valuestring:""));
			strcpy(stWifiIface.Hidden, (cJSON_GetObjectItem(json_value, "hidden")?cJSON_GetObjectItem(json_value, "hidden")->valuestring:""));
			(void)WifiUciAdd(&stWifiDevice, &stWifiIface);
			break;

		case WIFIDEL:
			strcpy(device, (cJSON_GetObjectItem(json_value, "wifi-device")?cJSON_GetObjectItem(json_value, "wifi-device")->valuestring:""));
			index = cJSON_GetObjectItem(json_value, "delindex")?cJSON_GetObjectItem(json_value, "delindex")->valueint:0xffff;
			(void)WifiUciDel(device, index);
			break;

		case WIFIEDIT:
			index = cJSON_GetObjectItem(json_value, "index")?cJSON_GetObjectItem(json_value, "index")->valueint:0;
			strcpy(stWifiDevice.WifiDevice, (cJSON_GetObjectItem(json_value, "wifi-device")?cJSON_GetObjectItem(json_value, "wifi-device")->valuestring:""));
			strcpy(stWifiDevice.Type, (cJSON_GetObjectItem(json_value, "type")?cJSON_GetObjectItem(json_value, "type")->valuestring:""));
			strcpy(stWifiDevice.Country, (cJSON_GetObjectItem(json_value, "country")?cJSON_GetObjectItem(json_value, "country")->valuestring:""));
			strcpy(stWifiDevice.Channel, (cJSON_GetObjectItem(json_value, "channel")?cJSON_GetObjectItem(json_value, "channel")->valuestring:""));
			strcpy(stWifiDevice.Disabled, (cJSON_GetObjectItem(json_value, "disabled")?cJSON_GetObjectItem(json_value, "disabled")->valuestring:""));
			strcpy(stWifiIface.Device, (cJSON_GetObjectItem(json_value, "device")?cJSON_GetObjectItem(json_value, "device")->valuestring:""));
			strcpy(stWifiIface.Network, (cJSON_GetObjectItem(json_value, "network")?cJSON_GetObjectItem(json_value, "network")->valuestring:""));
			strcpy(stWifiIface.Mode, (cJSON_GetObjectItem(json_value, "mode")?cJSON_GetObjectItem(json_value, "mode")->valuestring:""));
			strcpy(stWifiIface.Ssid, (cJSON_GetObjectItem(json_value, "ssid")?cJSON_GetObjectItem(json_value, "ssid")->valuestring:""));
			strcpy(stWifiIface.Encryption, (cJSON_GetObjectItem(json_value, "encryption")?cJSON_GetObjectItem(json_value, "encryption")->valuestring:""));
			strcpy(stWifiIface.Key, (cJSON_GetObjectItem(json_value, "key")?cJSON_GetObjectItem(json_value, "key")->valuestring:""));
			strcpy(stWifiIface.Wds, (cJSON_GetObjectItem(json_value, "wds")?cJSON_GetObjectItem(json_value, "wds")->valuestring:""));
			strcpy(stWifiIface.Ifname, (cJSON_GetObjectItem(json_value, "ifname")?cJSON_GetObjectItem(json_value, "ifname")->valuestring:""));
			strcpy(stWifiIface.Hidden, (cJSON_GetObjectItem(json_value, "hidden")?cJSON_GetObjectItem(json_value, "hidden")->valuestring:""));
			(void)WifiUciEdit(&stWifiDevice, &stWifiIface, index);
			break;

		case WIFIGET:
			pstWifiIface = WifiInfoGet(&tablenum);
			if(NULL != pstWifiIface)
			{
				cJSON_AddItemToObject(json_value,"list",array=cJSON_CreateArray());
				for(index =0; index < tablenum; index++)
				{
					cJSON_AddItemToArray(array,obj=cJSON_CreateObject());
					cJSON_AddItemToObject(obj,"mode",cJSON_CreateString(pstWifiIface->Mode));
					cJSON_AddItemToObject(obj,"ssid",cJSON_CreateString(pstWifiIface->Ssid));
					cJSON_AddItemToObject(obj,"encryption",cJSON_CreateString(pstWifiIface->Encryption));
					cJSON_AddItemToObject(obj,"key",cJSON_CreateString(pstWifiIface->Key));
					pstWifiIface++;
				}
			}
			free(pstWifiIface);
			pstWifiIface = NULL;
			break;

		default:
			break;
	
	}
	
	return ;	
}
