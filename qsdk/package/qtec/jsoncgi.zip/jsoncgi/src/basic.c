#include "basic.h"

const char * base64char = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
//����tokenid
int generatortokenid(char *tokenid)
{
    srand((int)time(0));
    int i =rand()%1000;
    //����MD5ֵ
    MD5_CTX ctx;
    unsigned char md[16];
    char buf[33]={'\0'};
    char tmp[3]={'\0'};
    MD5_Init(&ctx);
    MD5_Update(&ctx,&i,sizeof(i));
    MD5_Final(md,&ctx);

    for(i=0;i<16;i++){
        sprintf(tmp,"%02x",md[i]);
        strcat(buf,tmp);
    }
  
    snprintf(tokenid,MAX_TOKENID_LEN,"%s",buf);
  
    return 0;
}



//base64 ����
char * base64_encode( const unsigned char * bindata, char * base64, int binlength )
{
    int i, j;
    unsigned char current;

    for ( i = 0, j = 0 ; i < binlength ; i += 3 )
    {
        current = (bindata[i] >> 2) ;
        current &= (unsigned char)0x3F;
        base64[j++] = base64char[(int)current];

        current = ( (unsigned char)(bindata[i] << 4 ) ) & ( (unsigned char)0x30 ) ;
        if ( i + 1 >= binlength )
        {
            base64[j++] = base64char[(int)current];
            base64[j++] = '=';
            base64[j++] = '=';
            break;
        }
        current |= ( (unsigned char)(bindata[i+1] >> 4) ) & ( (unsigned char) 0x0F );
        base64[j++] = base64char[(int)current];

        current = ( (unsigned char)(bindata[i+1] << 2) ) & ( (unsigned char)0x3C ) ;
        if ( i + 2 >= binlength )
        {
            base64[j++] = base64char[(int)current];
            base64[j++] = '=';
            break;
        }
        current |= ( (unsigned char)(bindata[i+2] >> 6) ) & ( (unsigned char) 0x03 );
        base64[j++] = base64char[(int)current];

        current = ( (unsigned char)bindata[i+2] ) & ( (unsigned char)0x3F ) ;
        base64[j++] = base64char[(int)current];
    }
    base64[j] = '\0';
    return base64;
}


//base64����
int base64_decode(char * base64, unsigned char * bindata )
{

    //gui ǰ�� ���ܻ��+�滻�ɿո�����������Ҫ����ת����
    //����������base64Ӧ�ò������ո�
    int length=0;
    for(length=0;length<strlen(base64);length++)
    {
        if(base64[length]==' ')
            base64[length]='+';
    }
    //end ת���ո�+
    
    int i, j;
    unsigned char k;
    unsigned char temp[4];
    for ( i = 0, j = 0; base64[i] != '\0' ; i += 4 )
    {
        memset( temp, 0xFF, sizeof(temp) );
        for ( k = 0 ; k < 64 ; k ++ )
        {
            if ( base64char[k] == base64[i] )
                temp[0]= k;
        }
        for ( k = 0 ; k < 64 ; k ++ )
        {
            if ( base64char[k] == base64[i+1] )
                temp[1]= k;
        }
        for ( k = 0 ; k < 64 ; k ++ )
        {
            if ( base64char[k] == base64[i+2] )
                temp[2]= k;
        }
        for ( k = 0 ; k < 64 ; k ++ )
        {
            if ( base64char[k] == base64[i+3] )
                temp[3]= k;
        }

        bindata[j++] = ((unsigned char)(((unsigned char)(temp[0] << 2))&0xFC)) |
                ((unsigned char)((unsigned char)(temp[1]>>4)&0x03));
        if ( base64[i+2] == '=' )
            break;

        bindata[j++] = ((unsigned char)(((unsigned char)(temp[1] << 4))&0xF0)) |
                ((unsigned char)((unsigned char)(temp[2]>>2)&0x0F));
        if ( base64[i+3] == '=' )
            break;

        bindata[j++] = ((unsigned char)(((unsigned char)(temp[2] << 6))&0xF0)) |
                ((unsigned char)(temp[3]&0x3F));
    }
    return j;
}


//���tokenid 
//������ɹ��򷵻�0�����򷵻ط�0
int webCheckTokenId()
{
    //����ǵ�һ�����ã�����ϵͳ��tokenid��ֵΪ0�� ����������ֱ�ӷ��سɹ�
    int system_configured=0;
    int ret=0;
    GetSystemConfigured(&system_configured);
    if(system_configured == 0)
    {
        DEBUG_PRINTF("[%s]====current system is not configured====\n",__func__);
        return 0;
    }

    //��ȡϵͳtoken id
    char tokenid[MAX_TOKENID_LEN]={0};
    ret=getTokenId(tokenid);
    if( (ret!=0) || (strlen(tokenid)==0) )
    {
        DEBUG_PRINTF("[%s]only when system is unconfigured, tokenid is null, but if this line is printed, so bad thing occur===\n",__func__);
        return -1;  
    }

    DEBUG_PRINTF("[%s]====system token id: %s ====\n",__func__,tokenid);
    
    //��ȡhttpͷ��tokenid
    char *httptokenid=NULL;
    httptokenid=getenv("HTTP_TOKEN_ID");

    DEBUG_PRINTF("[%s]===http token id: %s ====\n", __func__,httptokenid);

    if(httptokenid == NULL)
    {
        DEBUG_PRINTF("[%s] not have http token id===\n",__func__);
        return -1;
    }
    
    if(strlen(httptokenid) != strlen(tokenid) )
    {
        DEBUG_PRINTF("[%s] token id not match===\n",__func__);
        return -1;
    }

    if(strncmp(tokenid,httptokenid,strlen(tokenid)) != 0)
    {
        DEBUG_PRINTF("[%s] token id not match===\n",__func__);
        return -1;
    }
    else
    {
        DEBUG_PRINTF("[%s] token id match ===\n",__func__);
        return 0;
    }
    
}

/*
//�����ﶨ���������
enum web_error_code {
     ERR_NO_LOGIN = -100,
     ERR_URL_NOT_SUPPORT= -99,
     ERR_METHOD_NOT_SUPPORT=-98,
     ERR_PARAMETER_MISS=-97,
     ERR_VALUE_WRONG=-96,
     ERR_INTERNALLOGIC_WRONG=-95,
     ERR_OTHER=0
};

*/

int err2msg(int errcode,char *input_msg, int msg_len)
{
    DEBUG_PRINTF("[%s]===errcode: %d  msg_len: %d====\n",__func__,errcode,msg_len);
    switch(errcode)
    {
        case 0: //��Ϊ���������Ӧ�ö����سɹ�
            strncpy(input_msg,"success",msg_len);
            break;
        case ERR_NO_LOGIN:
            strncpy(input_msg,"not login",msg_len);
            break;
        case ERR_URL_NOT_SUPPORT:
            strncpy(input_msg,"url not support",msg_len);
            break;
        case ERR_METHOD_NOT_SUPPORT:
            strncpy(input_msg,"method not support",msg_len);
            break;
        case ERR_PARAMETER_MISS:
            strncpy(input_msg,"key parameter miss",msg_len);
            break;
        case ERR_VALUE_WRONG:
            strncpy(input_msg,"value illegal",msg_len);
            break;
        case ERR_INTERNALLOGIC_WRONG:
            strncpy(input_msg, "internal logic wrong", msg_len);
            break;
        case ERR_DECRY_FAIL:
            strncpy(input_msg, "password decry fail", msg_len);
            break;
        case ERR_PASSWORD_NOTMATCH:
            strncpy(input_msg, "password not match", msg_len);
            break;
        case ERR_WAN_IPWRONG:
            strncpy(input_msg, "wan miss ipaddress", msg_len);
            break;
        case ERR_WAN_GWWRONG:
            strncpy(input_msg, "wan gw wrong or cannot access gw", msg_len);
            break;
        case ERR_WAN_DNSWRONG:
            strncpy(input_msg, "wan cannot get DNS", msg_len);
            break;
        case ERR_WAN_INTERNETWRONG:
            strncpy(input_msg, "wan cannot access internet", msg_len);
            break;
        case ERR_WAN_NOTUP:
            strncpy(input_msg, "WAN not up or can not access server", msg_len);
            break;
   
        default:
            strncpy(input_msg, "unknown reason error", msg_len);
    }

    return 0;
}

//���ݴ����뷵��jason����
int err2replymsg(int errcode, char *input_url, cJSON * jsonOut)
{
    DEBUG_PRINTF("[%s]===errcode: %d====\n",__func__,errcode);
    cJSON_AddItemToObject(jsonOut, "errorcode", cJSON_CreateNumber(errcode));
    cJSON_AddItemToObject(jsonOut, "requestedurl", cJSON_CreateString(input_url));
    char msg[256]={0};
    err2msg(errcode, msg, sizeof(msg));
	cJSON_AddItemToObject(jsonOut, "msg", cJSON_CreateString(msg));
    return 0;
}

//����ping ���
//return 0 :��ʾ ��ping ͨ
//ping 192.168.1.1 -c 4  -I eth0.2 -q
int checkPingResult(char* input_destip, char* input_ifname)
{
    DEBUG_PRINTF("[%s]====input_destip: %s===input_ifname: %s\n",__func__,input_destip,input_ifname);
    FILE *fp;
    char cmd[256]={0};
    snprintf(cmd,256,"ping %s -c 4 -I %s -q",input_destip,input_ifname);
   
    fp=popen(cmd,"r");
    char line[256];
    if(fp != NULL)
    {
        while (fgets(line,sizeof(line),fp) != NULL)
        {
            if(strstr(line,"round-trip")!=NULL)
            {
                return 0;
            }
           
        }

        return 1;
    }
    else
    {
        DEBUG_PRINTF("[%s]====popen fail===\n",__func__);
        return -1;
    }
     
}