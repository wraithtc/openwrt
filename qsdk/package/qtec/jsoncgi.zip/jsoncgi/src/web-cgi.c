#include "basic.h"

int global_weberrorcode=0;
char global_requesturl[64]={0};
int request_method=0;
/*
  �� GET��SELECT�����ӷ�����ȡ����Դ��һ�������
  �� POST��CREATE�����ڷ������½�һ����Դ��
  �� PUT��UPDATE�����ڷ�����������Դ���ͻ����ṩ�ı���������Դ����
  �� PATCH��UPDATE�����ڷ�����������Դ���ͻ����ṩ�ı�����ԣ���
  �� DELETE��DELETE�����ӷ�����ɾ����Դ��
*/

/*
struct cgi_module{
    char module_name[64];
    int supportMethod; 
    void* func(cJSON *,cJSON *);
};

*/


struct cgi_module global_cgimoduleArray[]={
    { "getkeycfg", CGI_GET_METHOD, proc_rsacfg_getKey , 0},    //��ȡ��Կ
    { "logincfg",  CGI_PUT_METHOD, check_gui_password, 0},    //�û�����

    //����������
    { "get_systemconfigure_cfg", CGI_GET_METHOD, GetRouterConfigured,0},
    { "get_wantype_cfg",CGI_GET_METHOD, get_wan_type,0},  //��ȡ��ǰ������ʽ
    { "set_basicwan_cfg",CGI_PUT_METHOD, proc_wan_set,0}, //����wan����
    { "set_firstconfigure_cfg",CGI_PUT_METHOD, proc_firstconfigure_set,0},  //��һ������
    { "get_stalist_cfg", CGI_GET_METHOD, proc_stalist_get, 1},  //get stalist

    //wan detect
    { "get_wandect_cfg", CGI_GET_METHOD, proc_wan_detect,0},


    { "get_timertask_cfg", CGI_GET_METHOD, proc_timertask_detect,1},
    { "set_timertask_cfg", CGI_PUT_METHOD, proc_timertask_set,1},
    
    { "reboot", CGI_PUT_METHOD, proc_reboot,1},

    { "restore", CGI_PUT_METHOD, proc_restore,1},
        
    { "reset_guipassword_cfg", CGI_PUT_METHOD,reset_gui_password,1}, //��������gui ����Ա����
    { "handle_routerinfo_cfg", CGI_GET_METHOD | CGI_PUT_METHOD, HandleRouterBasicInfo, 1}, //��ȡ������·����������Ϣ


    { "upgrade", CGI_PUT_METHOD, proc_upgrade, 1},
    { "query_upgrade", CGI_PUT_METHOD, proc_queryupgrade, 1},
	
	//wireless
	{ "set_wireless_cfg", CGI_PUT_METHOD, proc_wifi_set, 1},
	{ "get_wireless_cfg", CGI_GET_METHOD, proc_wifi_get, 1},
};

#define NUM_CGI_MODULE (sizeof(global_cgimoduleArray)/sizeof(struct cgi_module))

int methodstr2int(char *input_method)
{
    int ret=0;
    if(strncmp(input_method,"get",strlen(input_method))==0)
    {
        ret=CGI_GET_METHOD;
    }
    else if(strncmp(input_method,"post",strlen(input_method))==0)
    {
        ret=CGI_POST_METHOD;
    }
    else if(strncmp(input_method,"put",strlen(input_method))==0)
    {
        ret=CGI_PUT_METHOD;
    }
    else if(strncmp(input_method,"PATCH",strlen(input_method))==0)
    {
        ret=CGI_PATCH_METHOD;
    }
    else if(strncmp(input_method,"DELETE",strlen(input_method))==0)
    {
        ret=CGI_DELETE_METHOD;
    }

    return ret;
}


void decode_message(char *msg)
{
	cJSON *json, *jsonValue, *jsonOut;
	char *target, *buffer, *method;
	int  f0, f1, f2;
	
	json = cJSON_Parse(msg);
	if (!json)
	{
		printf("error!");
		return;		
	}

    //����ӡ���������
	f0 = dup(STDOUT_FILENO);
	f1 = open("/dev/console", O_RDWR);
	f2 = dup2(f1, STDOUT_FILENO);
	close(f1);
	

	target = cJSON_GetObjectItem(json, "requestUrl")?cJSON_GetObjectItem(json, "requestUrl")->valuestring:"";
    method = cJSON_GetObjectItem(json, "method")?cJSON_GetObjectItem(json, "method")->valuestring:"";
    DEBUG_PRINTF("===target: %s===\n", target);
    DEBUG_PRINTF("===method: %s=== \n",method);
   
    request_method = methodstr2int(method);
    strncpy(global_requesturl,target,sizeof(global_requesturl));
    
	jsonValue = cJSON_GetObjectItem(json, "data");
	
	jsonOut = cJSON_CreateObject();

    int num = NUM_CGI_MODULE;
  
    
    int index=0;
    for(index=0;index<num;index++)
    {
        if(strncmp(target,global_cgimoduleArray[index].module_name,strlen(target))==0)
        {
            if((request_method & global_cgimoduleArray[index].supportMethod) == 0)
            {
                global_weberrorcode=ERR_METHOD_NOT_SUPPORT;
                goto OUT;
            }
            else
            {
                //���tokenid
                if( global_cgimoduleArray[index].need_token_auth == 1)
                {
                    int ret=webCheckTokenId();
                    if(ret<0)
                    {
                        DEBUG_PRINTF("[%s]====tokenid auth fail===\n",__func__);
                        global_weberrorcode=ERR_NO_LOGIN;
                        goto OUT;
                    }
                }

                global_cgimoduleArray[index].handle(jsonValue, jsonOut);

                goto OUT;
            }
        }
    }
    
    if(index == num)
    {
        global_weberrorcode = ERR_URL_NOT_SUPPORT;
    }
   
    
#if 0
    //�û�����ҳ��  �������
    if(strncmp(target,"logincfg",strlen(target))==0)
    {
        if( (strncmp(method,"post",strlen(method))==0) || (strncmp(method,"POST",strlen(method))==0) )
        {
            check_gui_password(jsonValue, jsonOut);

        }
        else
        {
            global_weberrorcode=ERR_METHOD_NOT_SUPPORT;
            
        }

        goto OUT;
    }
    else if(strncmp(target,"getkeycfg",strlen(target))==0)
    {
        if( (strncmp(method,"get",strlen(method))==0) || (strncmp(method,"GET",strlen(method))==0) )
        {
            proc_rsacfg_getKey(jsonValue,jsonOut);
        }
        else
        {
            global_weberrorcode=ERR_METHOD_NOT_SUPPORT;
            
        }
        goto OUT;
    }
    else
    {
        int ret=webCheckTokenId();
        if(ret !=0)
        {
            DEBUG_PRINTF("[%s]====token id check fail==\n");

            global_weberrorcode=ERR_NO_LOGIN;
            
            goto OUT;
        }
    }
    //wan���
	if (strncmp(target,"wancfg",strlen(target))==0 )
	{
        DEBUG_PRINTF("====[%s]====%d===\n",__func__,__LINE__);
        if( (strncmp(method,"put",strlen(method)) == 0) || (strncmp(method,"PUT",strlen(method))==0) )
        {
            
            proc_wan_set(jsonValue,jsonOut);
        }
        else if( (strncmp(method,"get",strlen(method)) == 0) || (strncmp(method,"GET",strlen(method))==0 ) )
        {
            
            proc_wan_get(jsonValue,jsonOut);
        }
        else
        {
            
            cJSON_AddItemToObject(jsonOut, "code", cJSON_CreateNumber(1));	
	        cJSON_AddItemToObject(jsonOut, "msg", cJSON_CreateString("wancfg don't support this method"));
            
        }
         
	}
    //wireless ���
	else if (strncmp(target,"wirelesscfg",strlen(target))==0)
	{
        if( (strncmp(method,"put",strlen(method))==0) || (strncmp(method,"PUT",strlen(method))==0) )
        {
            
            proc_wireless_set(jsonValue,jsonOut);
        }
		else if( (strncmp(method,"get",strlen(method))==0) || (strncmp(method,"GET",strlen(method))==0) )
		{
            proc_wireless_get(jsonValue,jsonOut);
		}
        else
		{
            
            cJSON_AddItemToObject(jsonOut, "code", cJSON_CreateNumber(1));	
	        cJSON_AddItemToObject(jsonOut, "msg", cJSON_CreateString("wirelesscfg don't support this method"));
		}
	}
	else if (strncmp(target,"landhcpcfg",strlen(target))==0)
	{
		DEBUG_PRINTF("====[%s]=====%d====\n",__func__,__LINE__);
        if( (strncmp(method,"get",strlen(method)) == 0) || (strncmp(method,"GET",strlen(method))==0) )
        {
            proc_landhcp_get(jsonValue,jsonOut);
        }
        else if( (strncmp(method,"put",strlen(method)) ==0 ) || (strncmp(method,"PUT",strlen(method))==0))
        {
            proc_landhcp_set(jsonValue,jsonOut);
        }
        else
        {
            cJSON_AddItemToObject(jsonOut, "code", cJSON_CreateNumber(1));	
	        cJSON_AddItemToObject(jsonOut, "msg", cJSON_CreateString("landhcp config don't support this method"));
        }
	}
    else if(strncmp(target,"staticleasecfg",strlen(target))==0)
    {
        DEBUG_PRINTF("====[%s]====%d====\n",__func__,__LINE__);
        //���Ӿ�̬�����ַ
        if( (strncmp(method,"post",strlen(method))==0) || (strncmp(method,"POST",strlen(method))==0) )
        {
            proc_staticlease_add(jsonValue,jsonOut);
        }
        else if( (strncmp(method,"delete",strlen(method)) == 0) || (strncmp(method,"DELETE",strlen(method))==0) )
        {   
            proc_staticlease_del(jsonValue,jsonOut);
        }
        else if( (strncmp(method,"get",strlen(method))==0) || (strncmp(method,"GET",strlen(method))==0) )
        {
            proc_staticlease_getall(jsonValue, jsonOut);
        }
        else
        {
            cJSON_AddItemToObject(jsonOut, "code", cJSON_CreateNumber(1));	
	        cJSON_AddItemToObject(jsonOut, "msg", cJSON_CreateString("static lease config don't support this method"));
        }
    }
    
	else if(strncmp(target,"pfcfg",strlen(target))==0)
	{
		if( (strncmp(method,"post",strlen(method)) ==0) || (strncmp(method,"POST",strlen(method))==0) )
		{
            proc_PF_add(jsonValue, jsonOut);
		}
        else if( (strncmp(method,"delete",strlen(method)) == 0 ) || (strncmp(method,"DELETE",strlen(method))==0) )
        {
            proc_PF_del(jsonValue,jsonOut);
        }
        else if( (strncmp(method,"put",strlen(method)) == 0) || (strncmp(method,"PUT",strlen(method))==0) )
        {
            proc_PF_edit(jsonValue, jsonOut);
        }
        else if( (strncmp(method,"get",strlen(method))==0) || (strncmp(method,"GET",strlen(method))==0) )
        {
            proc_PF_getall(jsonValue, jsonOut);
        }
        else
        {
            
            cJSON_AddItemToObject(jsonOut, "code", cJSON_CreateNumber(1));	
	        cJSON_AddItemToObject(jsonOut, "msg", cJSON_CreateString("pfcfg don't support this method"));
        }
	}
	else if(strncmp(target,"ntpcfg",strlen(target))==0)
	{
        if( (strncmp(method,"put",strlen(method)) == 0) || (strncmp(method,"PUT",strlen(method))==0) )
        {
            proc_ntp_set(jsonValue,jsonOut);
        }
        else if( (strncmp(method,"get",strlen(method)) == 0) || (strncmp(method,"GET",strlen(method))==0 ) )
        {
            proc_ntp_get(jsonValue,jsonOut);
        }
        else
        {
   
            cJSON_AddItemToObject(jsonOut, "code", cJSON_CreateNumber(1));	
	        cJSON_AddItemToObject(jsonOut, "msg", cJSON_CreateString("ntpcfg don't support this method"));
            
        }
	}
    else if(strncmp(target,"routerinfo",strlen(target))==0)
    {
        if( (strncmp(method,"get",strlen(method)) ==0 ) || (strncmp(method,"GET",strlen(method))==0) )
        {
            GetRouterInfo(jsonValue, jsonOut);
        }
        else
        {
            cJSON_AddItemToObject(jsonOut, "code", cJSON_CreateNumber(1));	
	        cJSON_AddItemToObject(jsonOut, "msg", cJSON_CreateString("router info don't support this method"));
            
        }
    }
#if 0
    else if (strncmp(target,"getkeycfg",strlen(target))==0)
    {
        if( (strncmp(method,"get",strlen(method)) ==0 ) || (strncmp(method,"GET",strlen(method)) == 0 ) )
        {
            proc_rsacfg_getKey(jsonValue,jsonOut);
        }
        else
        {
            cJSON_AddItemToObject(jsonOut, "code", cJSON_CreateNumber(1));	
	        cJSON_AddItemToObject(jsonOut, "msg", cJSON_CreateString("getkeycfg don't support this method"));
        }
    }
#endif 
    else if (strncmp(target,"guipasswordcfg",strlen(target))==0 )
	{
        printf("====[%s]====%d===\n",__func__,__LINE__);

        if( (strncmp(method,"test",strlen(method)) == 0) || (strncmp(method,"TEST",strlen(method))==0) )
        {
            DEBUG_PRINTF("===[%s]===[%d]====\n",__func__,__LINE__); fflush(stdout);
            proc_rsacfg_encrypt(jsonValue,jsonOut);
            
        }
        else if( (strncmp(method,"post",strlen(method))==0) || (strncmp(method,"POST",strlen(method))==0) )
        {
            proc_gui_password(jsonValue, jsonOut);
        }
        else
        {
            
            cJSON_AddItemToObject(jsonOut, "code", cJSON_CreateNumber(1));	
	        cJSON_AddItemToObject(jsonOut, "msg", cJSON_CreateString("rsacfg don't support this method"));     
        }
	}
    else
    {
        cJSON_AddItemToObject(jsonOut, "code", cJSON_CreateNumber(1));  
	    cJSON_AddItemToObject(jsonOut, "msg", cJSON_CreateString("not support this url"));
    }
#endif 

OUT:
    err2replymsg(global_weberrorcode, global_requesturl, jsonOut);
    
	fflush(stdout);
	dup2(f0, f2);
	buffer = cJSON_Print(jsonOut);
	printf("%s\n",buffer);
	free(buffer);

	cJSON_Delete(jsonOut);
	cJSON_Delete(json);
	
	return;
}

#if 1
int main()
{

	int length;
	char *method;
	char *inputstring;

	printf("Content-Type: application/json\n\n");

    fflush(stdout);
	method = getenv("REQUEST_METHOD"); 
 
	if(method == NULL)
	{
		return 1;   
	}
	
	//post method,read from stdin
	if(!strcmp(method, "POST")) 
	{

		length = atoi(getenv("CONTENT_LENGTH")); 
		if(length != 0)
		{
			inputstring = malloc(sizeof(char)*length + 1); 
			if (0 != fread(inputstring, sizeof(char), length, stdin)) 
			{
				decode_message(inputstring);
			}
	    }
	}

	//get method
	else if(!strcmp(method, "GET"))
	{

		inputstring = getenv("QUERY_STRING");   
		length = strlen(inputstring);

	}

	return 0;
}
#endif


//�������Ի�ȡhttpͷ��Ϣ
int http_main()
{
    extern char   **environ;
    int nlen = 0;
    int i;
    char szContent[MAX_CONTENT_LEN];
    char **penv;
    char *req = NULL;

    memset(szContent, 0, MAX_CONTENT_LEN);
        
    printf("Content-type: text/html\n\n");
    
    for ( penv = environ; *penv; penv++ )
        printf("%s<br>", *penv);

    if ( strcmp("POST", getenv("REQUEST_METHOD")) == 0 )
    {
        nlen = atoi(getenv("CONTENT_LENGTH"));
        for (i = 0; i < nlen; i++ )    
        {
            if ( i < MAX_CONTENT_LEN )
                szContent[i] = fgetc(stdin);
            else
                break;
        }
        printf("<p>%s</p>", szContent);
    }

    char *TOKEN_ID=NULL;
    TOKEN_ID=getenv("HTTP_TOKEN_ID");
    printf("<p>%s</p>",TOKEN_ID);
    return 0;
}

//��main��������������
void debug_main()
//void main()
{
   // proc_wan_detect();    
#if 0
   int i=checkPingResult("1.1.342.3242", "eth0.2");
   DEBUG_PRINTF("====i: %d ====\n",i);
   DEBUG_PRINTF("===2===\n");

   i=checkPingResult("192.168.90.1","eth0.2");
    DEBUG_PRINTF("====i: %d ====\n",i);

   DEBUG_PRINTF("===3====\n");
   i=checkPingResult("12.0.0.1","eth0.2");
   DEBUG_PRINTF("====i: %d ====\n",i);
   DEBUG_PRINTF("====4====\n");
   i=checkPingResult("192.168.90.1", "eth0.342");
   DEBUG_PRINTF("====i: %d ====\n",i);
#endif 
}
