#include "basic.h"


int proc_timertask_set(cJSON *jsonValue,cJSON *jsonOut)
{
    int f0, f1, f2, lTaskType;
    char *outBuff;
    TIMER_TASK_STRU taskInfo = {0}, *pTaskInfo;
    int taskType, timeMin, timeHour, ret = 0;
    char *timeDay, *outStr;

    if (!cJSON_GetObjectItem(jsonValue, "tasktype") 
        || !cJSON_GetObjectItem(jsonValue, "minute") 
        || !cJSON_GetObjectItem(jsonValue, "hour")
        || !cJSON_GetObjectItem(jsonValue, "enable")
        || !cJSON_GetObjectItem(jsonValue, "day"))
    {
        printf("Miss argument to set timer task!\n");
        outStr = "Miss argument to set timer task!";
        return -1;	
    }
    taskInfo.ucTaskType = cJSON_GetObjectItem(jsonValue, "tasktype")->valueint;
    taskInfo.ucTimerMin = cJSON_GetObjectItem(jsonValue, "minute")->valueint;
    taskInfo.ucTimerHour = cJSON_GetObjectItem(jsonValue, "hour")->valueint;
    taskInfo.ucEnable = cJSON_GetObjectItem(jsonValue, "enable")->valueint;
    taskInfo.usTaskId = taskInfo.ucTaskType;
    strncpy(taskInfo.aucTimeWeek, cJSON_GetObjectItem(jsonValue, "day")->valuestring, sizeof(taskInfo.aucTimeWeek));
    if (taskInfo.ucEnable)
    {
        TimerTaskLoadConfig();
        TimerTaskEnable(&taskInfo);
        
    }
    else
    {
        TimerTaskLoadConfig();
        TimerTaskDisable(&taskInfo);
    }
    TimerTaskSaveConfig();
    TimerTaskRun();

    return 0;
}

int proc_timertask_detect(cJSON *jsonValue,cJSON *jsonOut)
{
    TIMER_TASK_STRU *pTaskInfo;
    char *timeDay, *outStr;
    int lTaskType;
    cJSON *dataObj;
    
    if (!cJSON_GetObjectItem(jsonValue, "tasktype"))
    {
        printf("Miss argument to get timer task!\n");
        outStr = "Miss argument to get timer task!";
        return -1;	
    }
    lTaskType = cJSON_GetObjectItem(jsonValue, "tasktype")->valueint;
    if ((pTaskInfo = TimerTaskGetTask(lTaskType)) == NULL)
    {
        outStr = "Fail to get timer task!";
        return -1;
    }
    dataObj = cJSON_CreateObject();
    if (dataObj == NULL)
    {
        printf("Fail to create data json obj!\n");
        outStr = "Fail to create data json obj!";
        return -1;	
    }
    cJSON_AddItemToObject(dataObj, "minute", cJSON_CreateNumber(pTaskInfo->ucTimerMin));
	cJSON_AddItemToObject(dataObj, "hour", cJSON_CreateNumber(pTaskInfo->ucTimerHour));
	cJSON_AddItemToObject(dataObj, "enable", cJSON_CreateNumber(pTaskInfo->ucEnable));
    cJSON_AddItemToObject(dataObj, "day", cJSON_CreateString(pTaskInfo->aucTimeWeek));
    cJSON_AddItemToObject(jsonOut, "data", dataObj);
    return 0;
}



