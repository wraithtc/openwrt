#include "basic.h"

void proc_PF_add(cJSON *json_value, cJSON *jsonOut)
{
    DEBUG_PRINTF("===%s===\n",__func__);
    struct portForwardRule portForwardNode = {0};
    int ret=0;
    portForwardNode.src_dport = cJSON_GetObjectItem(json_value, "srcport")?cJSON_GetObjectItem(json_value, "srcport")->valueint:0;
	portForwardNode.dest_port = cJSON_GetObjectItem(json_value, "destport")?cJSON_GetObjectItem(json_value, "destport")->valueint:0;
	strcpy(portForwardNode.name, (cJSON_GetObjectItem(json_value, "name")?cJSON_GetObjectItem(json_value, "name")->valuestring:""));
	strcpy(portForwardNode.proto, (cJSON_GetObjectItem(json_value, "proto")?cJSON_GetObjectItem(json_value, "proto")->valuestring:""));
	strcpy(portForwardNode.dest_ip, (cJSON_GetObjectItem(json_value, "destip")?cJSON_GetObjectItem(json_value, "destip")->valuestring:""));
    ret=addPortForwardRule(&portForwardNode);
    if(ret !=0)
    {
        cJSON_AddItemToObject(jsonOut, "code", cJSON_CreateNumber(1));  
	    cJSON_AddItemToObject(jsonOut, "msg", cJSON_CreateString("PortForward add fail"));
        
    }
    else
    {
        cJSON_AddItemToObject(jsonOut, "code", cJSON_CreateNumber(0));	
	    cJSON_AddItemToObject(jsonOut, "msg", cJSON_CreateString("success"));
       
    }
}

void proc_PF_del(cJSON *json_value, cJSON *jsonOut)
{
    DEBUG_PRINTF("===%s===\n",__func__);
    int index=0;
    int ret=0;
    index= cJSON_GetObjectItem(json_value, "delindex")?cJSON_GetObjectItem(json_value, "delindex")->valueint:0;
    ret=delPortForwardRule(index);
    if(ret !=0)
    {
        cJSON_AddItemToObject(jsonOut, "code", cJSON_CreateNumber(1));  
	    cJSON_AddItemToObject(jsonOut, "msg", cJSON_CreateString("PortForward del fail"));
        
    }
    else
    {
        cJSON_AddItemToObject(jsonOut, "code", cJSON_CreateNumber(0));	
	    cJSON_AddItemToObject(jsonOut, "msg", cJSON_CreateString("success"));
       
    }
}

void proc_PF_edit(cJSON *json_value, cJSON *jsonOut)
{
    DEBUG_PRINTF("===%s===\n",__func__);
    int index=0;
    int ret=0;
    struct portForwardRule portForwardNode = {0};
    index= cJSON_GetObjectItem(json_value, "index")?cJSON_GetObjectItem(json_value, "index")->valueint:0;
    portForwardNode.dest_port = cJSON_GetObjectItem(json_value, "destport")?cJSON_GetObjectItem(json_value, "destport")->valueint:0;
	strcpy(portForwardNode.name, (cJSON_GetObjectItem(json_value, "name")?cJSON_GetObjectItem(json_value, "name")->valuestring:""));
	strcpy(portForwardNode.proto, (cJSON_GetObjectItem(json_value, "proto")?cJSON_GetObjectItem(json_value, "proto")->valuestring:""));
	strcpy(portForwardNode.dest_ip, (cJSON_GetObjectItem(json_value, "destip")?cJSON_GetObjectItem(json_value, "destip")->valuestring:""));
    ret=editPortForwardRule(&portForwardNode, index);
    if(ret !=0)
    {
        cJSON_AddItemToObject(jsonOut, "code", cJSON_CreateNumber(1));  
	    cJSON_AddItemToObject(jsonOut, "msg", cJSON_CreateString("PortForward edit fail"));
        
    }
    else
    {
        cJSON_AddItemToObject(jsonOut, "code", cJSON_CreateNumber(0));	
	    cJSON_AddItemToObject(jsonOut, "msg", cJSON_CreateString("success"));
       
    }
}

void proc_PF_getall(cJSON *json_value, cJSON *jsonOut)
{
    DEBUG_PRINTF("===%s===\n",__func__);
    cJSON *array = NULL;
	cJSON *obj = NULL;
    int index=0;
    int tablenum=0;
    struct portForwardRule *pstPortForwardGet = NULL;
    pstPortForwardGet = getPortForwardRuleTable(&tablenum);
	
	cJSON_AddItemToObject(jsonOut,"list",array=cJSON_CreateArray());
	for(index =0; index < tablenum; index++)
	{
        cJSON_AddItemToArray(array,obj=cJSON_CreateObject());
		cJSON_AddItemToObject(obj,"name",cJSON_CreateString(pstPortForwardGet[index].name));
		cJSON_AddItemToObject(obj,"proto",cJSON_CreateString(pstPortForwardGet[index].proto));
		cJSON_AddItemToObject(obj,"destip",cJSON_CreateString(pstPortForwardGet[index].dest_ip));
		cJSON_AddItemToObject(obj,"srcport",cJSON_CreateNumber(pstPortForwardGet[index].src_dport));
		cJSON_AddItemToObject(obj,"destport",cJSON_CreateNumber(pstPortForwardGet[index].dest_port));
		
	}

    if(pstPortForwardGet)
	    free(pstPortForwardGet);

    cJSON_AddItemToObject(jsonOut, "code", cJSON_CreateNumber(0));	
	cJSON_AddItemToObject(jsonOut, "msg", cJSON_CreateString("success"));
}