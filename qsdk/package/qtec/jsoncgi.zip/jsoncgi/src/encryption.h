#ifndef ENCRYPTION_H
#define ENCRYPTION_H

#include <stdio.h>
#include <stdlib.h>
#pragma pack(1)

typedef struct _RemoteInfo
{
	long remoteUserId;
	char remoteDevicedId[16];
}RemoteInfo;



typedef struct _SrcMessage
{
	char  mesType;
	short reqId;
	char  keyType;
	char  keyNumber;
	char  keyLength;
	char  specified;
	char  shareNumber;
	long  localUserId;
	char  localDeviceId[32];
}SrcMessage;

typedef struct _DestMessage
{
	char  mesType;
	short reqId;
	char  status;
	char  keyType;
	char  keyNumber;
	char  keyLength;
	char  reserved;
	long  pushUserId;
	char  pushDeviceId[32];
	char  *keyId;
	char  *key;
}DestMessage;

#pragma pack()
#endif
