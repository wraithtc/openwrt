#include "basic.h"

void GetRouterInfo(cJSON *jsonValue, cJSON *jsonOut)
{
	struct systemInfo output = {0};
	cJSON *obj = NULL;

	obj = cJSON_CreateObject();
	if(NULL == obj)
	{
		return;
	}

	(void)getSystemInfo(&output);
	cJSON_AddItemToObject(jsonOut, "data", obj);
	cJSON_AddItemToObject(obj, "hostname", cJSON_CreateString(output.product));
	cJSON_AddItemToObject(obj, "version", cJSON_CreateString(output.productVersion));
	cJSON_AddItemToObject(obj, "serialnum", cJSON_CreateString(output.serialnum));
	cJSON_AddItemToObject(obj, "devmodel", cJSON_CreateString("mt7621a"));
	cJSON_AddItemToObject(obj, "configured", cJSON_CreateNumber(output.configured));
	

}

//��ȡ�Ƿ��ǵ�һ������
void GetRouterConfigured(cJSON *jsonValue, cJSON *jsonOut)
{
    cJSON *obj = NULL;
	obj = cJSON_CreateObject();
    cJSON_AddItemToObject(jsonOut, "data", obj);
    int configured=0;
    GetSystemConfigured(&configured);
    cJSON_AddItemToObject(obj, "configured", cJSON_CreateNumber(configured));
    
}


void proc_reboot(cJSON *jsonValue, cJSON *jsonOut)
{
    QtReboot();
}

void proc_restore(cJSON *jsonValue, cJSON *jsonOut)
{
    QtRestore();
}

//��ȡ·����������Ϣ
void GetRouterBasicInfo(cJSON *jsonValue, cJSON *jsonOut)
{
    DEBUG_PRINTF("[%s]====\n",__func__);
    cJSON *obj = NULL;
	obj = cJSON_CreateObject();
    cJSON_AddItemToObject(jsonOut, "data", obj);

    char router_name[64]={0};
    char ssid1[64]={0};
    char ssid2[64]={0};
    char lanip[64]={0};
    char wanip[64]={0};

    rtcfgUciGet("system.@system[0].routername",router_name);

    //����Ĭ����
    if(strlen(router_name) == 0 )
    {
        strncpy(router_name,"qtecrouter",sizeof(router_name));
    }

    rtcfgUciGet("wireless.@wifi-iface[0].ssid",ssid1);
    rtcfgUciGet("wireless.@wifi-iface[1].ssid",ssid2);
    rtcfgUciGet("network.lan.ipaddr",lanip);
    rtcfgUciGet("network.wan.ipaddr",wanip);

    cJSON_AddItemToObject(obj, "routername", cJSON_CreateString(router_name));
    cJSON_AddItemToObject(obj, "ssid1", cJSON_CreateString(ssid1));
    cJSON_AddItemToObject(obj, "ssid2", cJSON_CreateString(ssid2));
    cJSON_AddItemToObject(obj, "lanip", cJSON_CreateString(lanip));
    cJSON_AddItemToObject(obj, "wanip", cJSON_CreateString(wanip));    
}

//����·����������Ϣ
void SetRouterBasicInfo(cJSON *jsonValue, cJSON *jsonOut)
{
    DEBUG_PRINTF("[%s]=====\n",__func__);
    
    char routername[64]={0};
    strncpy(routername,cJSON_GetObjectItem(jsonValue, "routername")?cJSON_GetObjectItem(jsonValue, "routername")->valuestring:"",sizeof(routername));
    if(strlen(routername) == 0)
    {
        global_weberrorcode=ERR_PARAMETER_MISS;
        return;
    }
    char cmd[256]={0};
    int ret=0;
    snprintf(cmd,256,"system.@system[0].routername=%s",routername);
    ret=rtcfgUciSet(cmd);
    if(ret !=0)
    {
        global_weberrorcode=ERR_INTERNALLOGIC_WRONG;
    }
    
}

void HandleRouterBasicInfo(cJSON *jsonValue, cJSON *jsonOut)
{
    DEBUG_PRINTF("[%s]====\n",__func__);

    if( (request_method & CGI_GET_METHOD) != 0)
    {
        GetRouterBasicInfo(jsonValue, jsonOut);
    }
    else if ( (request_method & CGI_PUT_METHOD ) != 0 )
    {
        SetRouterBasicInfo(jsonValue, jsonOut);
    }
    else
    {
        global_weberrorcode=ERR_METHOD_NOT_SUPPORT;
    }
}

void proc_upgrade(cJSON *jsonValue, cJSON *jsonOut)
{
    int isKeepConfig = cJSON_GetObjectItem(jsonValue, "keepconfig")?cJSON_GetObjectItem(jsonValue, "keepconfig")->valueint:1;

    QtUpgradeSoftware(1);
}

VOS_RET_E proc_queryupgrade(cJSON *jsonValue, cJSON *jsonOut)
{
    cJSON *dataObj;
    char statusStr[32] = {0};
    VOS_RET_E ret;
    
    ret = QtQueryUpgrade(statusStr, (int)sizeof(statusStr));

    if (ret == VOS_RET_SUCCESS)
    {
        dataObj = cJSON_CreateObject();
        if (dataObj == NULL)
        {
            printf("Fail to create dataObj!\n");
            return VOS_RET_RESOURCE_EXCEEDED;
        }

        cJSON_AddItemToObject(dataObj, "status", cJSON_CreateString(statusStr));
        cJSON_AddItemToObject(jsonOut, "data", dataObj);
    }

    return ret;
}

