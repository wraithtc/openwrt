#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <QtKeyDistributeService.h>
#include <QtKeyEncrypt.h>
#include <QtkeyMangent.h>
#include "keyapi.h"

#ifdef __cplusplus
extern "C"{
#endif

struct tagCQtQkMangent
{
	CQtQkMangent cqtqkmangent;
};

struct tagCQtKeyEncrypt
{
	CQtKeyEncrypt cqtkeyencrypt;
};

struct tagCQtKeyDistribute
{
	CQtKeyDistribute *cqtkeydistribute;
};

struct tagCQtQkMangent *GetCQtQkMangent(void)  
{  
    return new struct tagCQtQkMangent;
} 

int AddRawKey(long userid)
{
	ListKeyID lKeyId;
	ListKey lKey;
	CQtKey cKey;
	CQtKeyId cKeyId;
	CQtDeviceId DeviceId;
	string keyId_tmp("");
	int id = 1234;
	int nRet = 0;
	CQtQkMangent *qkmangent = new CQtQkMangent();
	cKey.Clear();
	cKey.SetValue((BYTE *)"1234567812345678", BYTE(QT_MAX_KEY_LEN));
	for(int i = 0; i < 100; i++){
		keyId_tmp.clear();
		id++;
		keyId_tmp += "123456781234";
		std::stringstream ss;
		string tmp;
        ss << id;
		tmp = ss.str();
		keyId_tmp += tmp.c_str();
		cKeyId.SetValue((BYTE *)keyId_tmp.c_str(), BYTE(QT_MAX_KEY_ID_LEN));

		lKeyId.push_back(cKeyId);
		lKey.push_back(cKey);
	}
	
	nRet = qkmangent->AddKey(POOL_TYPE_RAW, userid, DeviceId, lKeyId, lKey);
	if(0 != nRet)
	{
		printf("main, qkmangent.AddKey error\n");
		return nRet;
	}
	return 0;
}

void ReleaseCQtQkMangent(struct tagCQtQkMangent **pstcqtqkmangent)  
{  
    delete *pstcqtqkmangent;  
    *pstcqtqkmangent = 0;  
} 

struct tagCQtKeyEncrypt *GetCQtKeyEncrypt(void)  
{  
    	return new struct tagCQtKeyEncrypt;
} 

void ReleaseCQtKeyEncrypt(struct tagCQtKeyEncrypt **pstcqtkeyencrypt)  
{  
    delete *pstcqtkeyencrypt;  
    *pstcqtkeyencrypt = 0;      
} 

struct tagCQtKeyDistribute *GetCQtKeyDistribute(void)  
{  
    return new struct tagCQtKeyDistribute;
} 

void ReleaseCQtKeyDistribute(struct tagCQtKeyDistribute **pstcqtkeydistribute)  
{  
    delete *pstcqtkeydistribute;  
    *pstcqtkeydistribute = 0;      
} 



int C_GetKeyByNode(struct tagCQtQkMangent *p,char nPoolType, char nNumber, long UserId, char *deviceid, char *lKeyId, char *lKey)
{
	printf("enter C_GetKeyByNode.\r\n");
	ListKeyID   listkeyid;
	ListKey     listkey;
	ListKeyID::iterator KeyIdItor;
	ListKey::iterator KeyItor;
	CQtDeviceId cqtdeviceid;
	char *keytemp = lKey;
	char *keyidtemp = lKeyId;
	int result = 0;

	cqtdeviceid.SetValue((unsigned char *)deviceid, sizeof(deviceid));
	
	result = p->cqtqkmangent.GetKeyByNode((unsigned char)nPoolType, (unsigned char)nNumber, UserId, cqtdeviceid, listkeyid, listkey);
	if(result)
	{
		printf("get key by userid failed.\r\n");
		return result;
	}

	KeyIdItor = listkeyid.begin();
	KeyItor = listkey.begin();
	
	for(KeyIdItor = listkeyid.begin(),KeyItor = listkey.begin(); \
		KeyIdItor != listkeyid.end(),KeyItor != listkey.end(); \
			++KeyIdItor,++KeyItor)
	{
		memset(keyidtemp, 0, 16);
		memset(keytemp, 0, 16);
		memcpy(keyidtemp, KeyIdItor->GetBuffer(), 16);
		memcpy(keytemp, KeyItor->GetBuffer(), 16);
		keytemp += 16;
		keyidtemp += 16;
	}
	return 0;
}
 
int C_GetKeyByIdNode(struct tagCQtQkMangent *p,char nPoolType, char nNumber, long UserId, char *deviceid, char *lKeyId, char *lKey)
{
	ListKey     listkey;
	ListKeyID      listkeyid;
	CQtDeviceId    cqtdeviceid;
	CQtKeyId       cktkeyid;
	ListKey::iterator KeyItor;
	int index;
	char *keytemp = lKey;
	int result = 0;

	cqtdeviceid.Clear();
	cqtdeviceid.SetValue((unsigned char *)deviceid, sizeof(deviceid));
	listkeyid.push_back(cktkeyid);
	
	for(index = 0; index < nNumber; index++)
	{
		cktkeyid.Clear();
		cktkeyid.SetValue((unsigned char *)(lKeyId + 16 * index), 16);
		listkeyid.push_back(cktkeyid);
	}

	result = p->cqtqkmangent.GetKeyByIdNode((unsigned char)nPoolType, (unsigned char)nNumber, UserId, cqtdeviceid, listkeyid, listkey);
	if(result)
	{
		printf("get key by keyid failed.\r\n");
		return result;
	}
	for(KeyItor = listkey.begin(); KeyItor != listkey.end(); ++KeyItor)
	{
		memcpy(keytemp, KeyItor->GetBuffer(), 16);
		keytemp += 16;
	}
	printf("enter C_GetKeyByIdNode.\r\n");
	return 0;
}

int C_DeleteKeyById(struct tagCQtQkMangent *p, char nPoolType, int keynumber, char *lKeyId)
{

	ListKeyID      listkeyid;
	CQtKeyId       cktkeyid;
	int index;
	int result = 0;

	for(index = 0; index < keynumber; index++)
	{
		cktkeyid.Clear();
		cktkeyid.SetValue((unsigned char *)(lKeyId + 16 * index), 16);
		listkeyid.push_back(cktkeyid);
	}
	
	result = p->cqtqkmangent.DeleteKeyById((unsigned char)nPoolType, listkeyid);
	if(result)
	{
		printf("DeleteKeyById failed.\r\n");
		return result;
	}
	printf("enter C_DeleteKeyById.\r\n");
	return 0;
}

int C_AddKey(struct tagCQtQkMangent *p,char nPoolType, int keynumber, long UserId, char *deviceid, char *lKeyId, char *lKey)
{

	ListKeyID      listkeyid;
	CQtKeyId       cktkeyid;
	ListKey        listkey;
	CQtKey         cktkey;
	ListKey::iterator KeyItor;
	int index;
	CQtDeviceId    cqtdeviceid;
	int result = 0;

	for(index = 0; index < keynumber; index++)
	{
		cktkeyid.Clear();
		cktkeyid.SetValue((unsigned char *)(lKeyId + 16 * index), 16);
		listkeyid.push_back(cktkeyid);

		cktkey.Clear();
		cktkey.SetValue((unsigned char *)(lKey + 16 * index), 16);
		listkey.push_back(cktkey);
	}
	
	cqtdeviceid.SetValue((unsigned char *)deviceid, sizeof(deviceid));
	
	result = p->cqtqkmangent.AddKey((unsigned char)nPoolType, UserId, cqtdeviceid, listkeyid, listkey);
	if(result)
	{
		printf("addkey failed.\r\n");
		return result;
	}

	printf("enter C_AddKey.\r\n");
	return 0;
}

int C_GetCount(struct tagCQtQkMangent *p,char nPoolType, int *pUsedCount, int *pUnusedCount, long UserId, char *deviceid)
{
	CQtDeviceId    cqtdeviceid;
	int result = 0;
	
	cqtdeviceid.SetValue((unsigned char *)deviceid, sizeof(deviceid));
	
	result = p->cqtqkmangent.GetCount((unsigned char)nPoolType, pUsedCount, pUnusedCount, UserId, cqtdeviceid);
	if(result)
	{
		printf("DeleteKeyById failed.\r\n");
		return result;
	}
	printf("enter C_GetCount.\r\n");
	return 0;
}


int C_EncryptOrDecrypt(struct tagCQtKeyEncrypt *p, char *dest, int *destLen, char *source, int sourceLen, char encryAlgType, char *key)
{
	int destlen;
	int result = 0;
	result = p->cqtkeyencrypt.EncryptOrDecrypt((unsigned char *)dest, destlen, (unsigned char *)source, sourceLen, (unsigned char)encryAlgType, (unsigned char *)key);
	if(result)
	{
		printf("DeleteKeyById failed.\r\n");
		return result;
	}
	return 0;
}


int C_DealClientSynReq(DestMessage *pDest, SrcMessage *pSrc)
{
	int result = 0;
	struct tagCQtQkMangent *pstcqtqkmangent;
	pstcqtqkmangent = GetCQtQkMangent();

	pDest->mesType = 102;
	pDest->reqId = pSrc->reqId;
	pDest->keyType = pSrc->keyType;
	pDest->keyNumber = pSrc->keyNumber;
	pDest->keyLength = pSrc->keyLength;
	pDest->pushUserId = pSrc->localUserId;
	strcpy(pDest->pushDeviceId, pSrc->localDeviceId);
	

	/* get rawkey */
	result += C_GetKeyByNode(pstcqtqkmangent, POOL_TYPE_RAW, pSrc->keyNumber, pSrc->localUserId, pSrc->localDeviceId, pDest->keyId, pDest->key);
	
	/* delete rawkey */
	result += C_DeleteKeyById(pstcqtqkmangent, POOL_TYPE_RAW, pSrc->keyNumber, pDest->keyId);

	/* save synkey */
	result += C_AddKey(pstcqtqkmangent, POOL_TYPE_SYNC, pSrc->keyNumber, pSrc->localUserId, pSrc->localDeviceId, pDest->keyId, pDest->key);
	
	ReleaseCQtQkMangent(&pstcqtqkmangent);
	if(result)
	{
		printf("C_DealClientSynReq failed.\r\n");
		return result;
	}
	return 0;
}


#ifdef __cplusplus
}
#endif

