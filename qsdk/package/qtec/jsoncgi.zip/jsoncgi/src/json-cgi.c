#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <libwebsockets.h>
#include <librtcfg.h>
#include "encryption.h"
#include "keyapi.h"
#include "cJSON.h"

typedef enum _Sm4Mode
{
	SM4_ECB_DEC = 0,
	SM4_ECB_ENC,
	SM4_CBC_ENC,
	SM4_CBC_DEC,
}Sm4Mode;

typedef enum _KeyType
{
	POOL_TYPE_RAW = 1,
	POOL_TYPE_SYNC
}KeyType;

#if 0
void proc_wan(cJSON *json_value, int method)
{
	struct wanStaticConfig wannode = {0};
	struct wanPppoeConfig  pppoeNode = {0};
	
	switch (method)
	{
		case WANDHCP:
			(void)wanDhcpConfigSet();
			break;

		case WANPPPOE:
			strcpy(pppoeNode.username, (cJSON_GetObjectItem(json_value, "username")?cJSON_GetObjectItem(json_value, "username")->valuestring:""));
			strcpy(pppoeNode.password, (cJSON_GetObjectItem(json_value, "password")?cJSON_GetObjectItem(json_value, "password")->valuestring:""));
			(void)wanPppoeConfigSet(&pppoeNode);
			break;

		case WANSTATIC:
	        strcpy(wannode.ipaddr, (cJSON_GetObjectItem(json_value, "ipaddr")?cJSON_GetObjectItem(json_value, "ipaddr")->valuestring:""));
			strcpy(wannode.netmask, (cJSON_GetObjectItem(json_value, "netmask")?cJSON_GetObjectItem(json_value, "netmask")->valuestring:""));
			strcpy(wannode.gateway, (cJSON_GetObjectItem(json_value, "gateway")?cJSON_GetObjectItem(json_value, "gateway")->valuestring:""));
			strcpy(wannode.dns, (cJSON_GetObjectItem(json_value, "dns")?cJSON_GetObjectItem(json_value, "dns")->valuestring:""));
			(void)wanStaticConfigSet(&wannode);
			break;

		default:
			break;
	}
	
	return;	
}

void proc_lan(cJSON *json_value, int method)
{
	int index = 0;
	int array_num = 0;
	cJSON *array = NULL;
	cJSON *obj = NULL;
	struct lanConfig lannode = {0};
	struct staticLeaseConfig staticnode = {0};
	struct staticLeaseConfig *pstStaticLeaseGet = NULL; 
	switch (method)
	{
		case LANSET:
			lannode.dhcpPoolStart = cJSON_GetObjectItem(json_value, "poolstart")?cJSON_GetObjectItem(json_value, "poolstart")->valueint:0;
			lannode.dhcpPoolLimit = cJSON_GetObjectItem(json_value, "poollimit")?cJSON_GetObjectItem(json_value, "poollimit")->valueint:0;
			strcpy(lannode.ipaddress, (cJSON_GetObjectItem(json_value, "ipaddress")?cJSON_GetObjectItem(json_value, "ipaddress")->valuestring:""));
			strcpy(lannode.netmask, (cJSON_GetObjectItem(json_value, "netmask")?cJSON_GetObjectItem(json_value, "netmask")->valuestring:""));
			(void)lanConfigSet(&lannode);
			break;

		case LANGET:
			(void)lanConfigGet(&lannode);
			cJSON_AddItemToObject(json_value,"poolstart",cJSON_CreateNumber(lannode.dhcpPoolStart));
			cJSON_AddItemToObject(json_value,"poollimit",cJSON_CreateNumber(lannode.dhcpPoolLimit));
			cJSON_AddItemToObject(json_value,"ipaddress",cJSON_CreateString(lannode.ipaddress));
			cJSON_AddItemToObject(json_value,"netmask",cJSON_CreateString(lannode.netmask));
			break;

		case LANADDSTATIC:
			strcpy(staticnode.hostname, (cJSON_GetObjectItem(json_value, "hostname")?cJSON_GetObjectItem(json_value, "hostname")->valuestring:""));
			strcpy(staticnode.mac, (cJSON_GetObjectItem(json_value, "mac")?cJSON_GetObjectItem(json_value, "mac")->valuestring:""));
			strcpy(staticnode.ipaddress, (cJSON_GetObjectItem(json_value, "ipaddress")?cJSON_GetObjectItem(json_value, "ipaddress")->valuestring:""));
			(void)addStaticLeaseEntry(&staticnode);
			break;

		case LANDELSTATIC:
			index = cJSON_GetObjectItem(json_value, "delindex")?cJSON_GetObjectItem(json_value, "delindex")->valueint:0;
			(void)delStaticLeaseEntry(index);
			break;

		case LANGETSTATIC:
			pstStaticLeaseGet = getStaticLeaseArray(&array_num);
			if(NULL != pstStaticLeaseGet)
			{
				cJSON_AddItemToObject(json_value,"list",array=cJSON_CreateArray());

				for(index = 0; index < array_num; index++)
				{
					cJSON_AddItemToArray(array,obj=cJSON_CreateObject());
					cJSON_AddItemToObject(json_value,"hostname",cJSON_CreateString(pstStaticLeaseGet->hostname));
					cJSON_AddItemToObject(json_value,"mac",cJSON_CreateString(pstStaticLeaseGet->mac));
					cJSON_AddItemToObject(json_value,"ipaddress",cJSON_CreateString(pstStaticLeaseGet->ipaddress));
					pstStaticLeaseGet++;
				}
			}
			free(pstStaticLeaseGet);
			pstStaticLeaseGet = NULL;
			break;

		default:
			break;
	}
    return;
}

void proc_firewall(cJSON *json_value, int method)
{
	int index = 0;
	int tablenum = 0;
	cJSON *array = NULL;
	cJSON *obj = NULL;
	struct portForwardRule portForwardNode = {0};
	struct portForwardRule *pstPortForwardGet = NULL;

	switch (method)
	{
		case PFADD:
			portForwardNode.src_dport = cJSON_GetObjectItem(json_value, "srcport")?cJSON_GetObjectItem(json_value, "srcport")->valueint:0;
			portForwardNode.dest_port = cJSON_GetObjectItem(json_value, "destport")?cJSON_GetObjectItem(json_value, "destport")->valueint:0;
			strcpy(portForwardNode.name, (cJSON_GetObjectItem(json_value, "name")?cJSON_GetObjectItem(json_value, "name")->valuestring:""));
			strcpy(portForwardNode.proto, (cJSON_GetObjectItem(json_value, "proto")?cJSON_GetObjectItem(json_value, "proto")->valuestring:""));
			strcpy(portForwardNode.dest_ip, (cJSON_GetObjectItem(json_value, "destip")?cJSON_GetObjectItem(json_value, "destip")->valuestring:""));
			(void)addPortForwardRule(&portForwardNode);
			break;

		case PFDEL:
			index = cJSON_GetObjectItem(json_value, "delindex")?cJSON_GetObjectItem(json_value, "delindex")->valueint:0;
			(void)delPortForwardRule(index);			
			break;

		case PFEDIT:
			index = cJSON_GetObjectItem(json_value, "index")?cJSON_GetObjectItem(json_value, "index")->valueint:0;
			portForwardNode.src_dport = cJSON_GetObjectItem(json_value, "srcport")?cJSON_GetObjectItem(json_value, "srcport")->valueint:0;
			portForwardNode.dest_port = cJSON_GetObjectItem(json_value, "destport")?cJSON_GetObjectItem(json_value, "destport")->valueint:0;
			strcpy(portForwardNode.name, (cJSON_GetObjectItem(json_value, "name")?cJSON_GetObjectItem(json_value, "name")->valuestring:""));
			strcpy(portForwardNode.proto, (cJSON_GetObjectItem(json_value, "proto")?cJSON_GetObjectItem(json_value, "proto")->valuestring:""));
			strcpy(portForwardNode.dest_ip, (cJSON_GetObjectItem(json_value, "destip")?cJSON_GetObjectItem(json_value, "destip")->valuestring:""));
			(void)editPortForwardRule(&portForwardNode, index);
			break;

		case PFGET:
			pstPortForwardGet = getPortForwardRuleTable(&tablenum);
			if(NULL != pstPortForwardGet)
			{
				cJSON_AddItemToObject(json_value,"list",array=cJSON_CreateArray());
				for(index =0; index < tablenum; index++)
				{
					cJSON_AddItemToArray(array,obj=cJSON_CreateObject());
					cJSON_AddItemToObject(obj,"name",cJSON_CreateString(pstPortForwardGet->name));
					cJSON_AddItemToObject(obj,"proto",cJSON_CreateString(pstPortForwardGet->proto));
					cJSON_AddItemToObject(obj,"destip",cJSON_CreateString(pstPortForwardGet->dest_ip));
					cJSON_AddItemToObject(obj,"srcport",cJSON_CreateNumber(pstPortForwardGet->src_dport));
					cJSON_AddItemToObject(obj,"destport",cJSON_CreateNumber(pstPortForwardGet->dest_port));
					pstPortForwardGet++;
				}
			}
			free(pstPortForwardGet);
			pstPortForwardGet = NULL;
			break;

		default:
			break;
	}

    return;
}

void proc_ntp(cJSON *json_value, int method)
{
	struct ntpConfig ntpNode = {0};

	switch (method)
	{
		case NTPSET:
			ntpNode.enable = cJSON_GetObjectItem(json_value, "enable")?cJSON_GetObjectItem(json_value, "enable")->valueint:0;
			strcpy(ntpNode.timezone, (cJSON_GetObjectItem(json_value, "timezone")?cJSON_GetObjectItem(json_value, "timezone")->valuestring:""));
			strcpy(ntpNode.ntpServers, (cJSON_GetObjectItem(json_value, "ntpservers")?cJSON_GetObjectItem(json_value, "ntpservers")->valuestring:""));
			(void)ntpConfigSet(&ntpNode);
			break;

		case NTPGET:
			(void)ntpConfigGet(&ntpNode);
			cJSON_AddItemToObject(json_value,"enable",cJSON_CreateNumber(ntpNode.enable));
			cJSON_AddItemToObject(json_value,"timezone",cJSON_CreateString(ntpNode.timezone));
			cJSON_AddItemToObject(json_value,"ntpservers",cJSON_CreateString(ntpNode.ntpServers));
			break;

		default:
			break;
	}

	return;
}

void proc_wireless(cJSON *json_value, int method)
{
	WifiDevice stWifiDevice = {0};
	WifiIface  stWifiIface = {0};
	cJSON *array = NULL;
	cJSON *obj = NULL;
	WifiIface  *pstWifiIface = NULL;
	char device[64] = {0};
	int index = 0;
	int tablenum = 0; 	
	
	switch (method)
	{
		case WIFIADD:
			strcpy(stWifiDevice.WifiDevice, (cJSON_GetObjectItem(json_value, "wifi-device")?cJSON_GetObjectItem(json_value, "wifi-device")->valuestring:""));
			strcpy(stWifiDevice.Type, (cJSON_GetObjectItem(json_value, "type")?cJSON_GetObjectItem(json_value, "type")->valuestring:""));
			strcpy(stWifiDevice.Country, (cJSON_GetObjectItem(json_value, "country")?cJSON_GetObjectItem(json_value, "country")->valuestring:""));
			strcpy(stWifiDevice.Channel, (cJSON_GetObjectItem(json_value, "channel")?cJSON_GetObjectItem(json_value, "channel")->valuestring:""));
			strcpy(stWifiDevice.Disabled, (cJSON_GetObjectItem(json_value, "disabled")?cJSON_GetObjectItem(json_value, "disabled")->valuestring:""));
			strcpy(stWifiIface.Device, (cJSON_GetObjectItem(json_value, "device")?cJSON_GetObjectItem(json_value, "device")->valuestring:""));
			strcpy(stWifiIface.Network, (cJSON_GetObjectItem(json_value, "network")?cJSON_GetObjectItem(json_value, "network")->valuestring:""));
			strcpy(stWifiIface.Mode, (cJSON_GetObjectItem(json_value, "mode")?cJSON_GetObjectItem(json_value, "mode")->valuestring:""));
			strcpy(stWifiIface.Ssid, (cJSON_GetObjectItem(json_value, "ssid")?cJSON_GetObjectItem(json_value, "ssid")->valuestring:""));
			strcpy(stWifiIface.Encryption, (cJSON_GetObjectItem(json_value, "encryption")?cJSON_GetObjectItem(json_value, "encryption")->valuestring:""));
			strcpy(stWifiIface.Key, (cJSON_GetObjectItem(json_value, "key")?cJSON_GetObjectItem(json_value, "key")->valuestring:""));
			strcpy(stWifiIface.Wds, (cJSON_GetObjectItem(json_value, "wds")?cJSON_GetObjectItem(json_value, "wds")->valuestring:""));
			strcpy(stWifiIface.Ifname, (cJSON_GetObjectItem(json_value, "ifname")?cJSON_GetObjectItem(json_value, "ifname")->valuestring:""));
			strcpy(stWifiIface.Hidden, (cJSON_GetObjectItem(json_value, "hidden")?cJSON_GetObjectItem(json_value, "hidden")->valuestring:""));
			(void)WifiUciAdd(&stWifiDevice, &stWifiIface);
			break;

		case WIFIDEL:
			strcpy(device, (cJSON_GetObjectItem(json_value, "wifi-device")?cJSON_GetObjectItem(json_value, "wifi-device")->valuestring:""));
			index = cJSON_GetObjectItem(json_value, "delindex")?cJSON_GetObjectItem(json_value, "delindex")->valueint:0xffff;
			(void)WifiUciDel(device, index);
			break;

		case WIFIEDIT:
			index = cJSON_GetObjectItem(json_value, "index")?cJSON_GetObjectItem(json_value, "index")->valueint:0;
			strcpy(stWifiDevice.WifiDevice, (cJSON_GetObjectItem(json_value, "wifi-device")?cJSON_GetObjectItem(json_value, "wifi-device")->valuestring:""));
			strcpy(stWifiDevice.Type, (cJSON_GetObjectItem(json_value, "type")?cJSON_GetObjectItem(json_value, "type")->valuestring:""));
			strcpy(stWifiDevice.Country, (cJSON_GetObjectItem(json_value, "country")?cJSON_GetObjectItem(json_value, "country")->valuestring:""));
			strcpy(stWifiDevice.Channel, (cJSON_GetObjectItem(json_value, "channel")?cJSON_GetObjectItem(json_value, "channel")->valuestring:""));
			strcpy(stWifiDevice.Disabled, (cJSON_GetObjectItem(json_value, "disabled")?cJSON_GetObjectItem(json_value, "disabled")->valuestring:""));
			strcpy(stWifiIface.Device, (cJSON_GetObjectItem(json_value, "device")?cJSON_GetObjectItem(json_value, "device")->valuestring:""));
			strcpy(stWifiIface.Network, (cJSON_GetObjectItem(json_value, "network")?cJSON_GetObjectItem(json_value, "network")->valuestring:""));
			strcpy(stWifiIface.Mode, (cJSON_GetObjectItem(json_value, "mode")?cJSON_GetObjectItem(json_value, "mode")->valuestring:""));
			strcpy(stWifiIface.Ssid, (cJSON_GetObjectItem(json_value, "ssid")?cJSON_GetObjectItem(json_value, "ssid")->valuestring:""));
			strcpy(stWifiIface.Encryption, (cJSON_GetObjectItem(json_value, "encryption")?cJSON_GetObjectItem(json_value, "encryption")->valuestring:""));
			strcpy(stWifiIface.Key, (cJSON_GetObjectItem(json_value, "key")?cJSON_GetObjectItem(json_value, "key")->valuestring:""));
			strcpy(stWifiIface.Wds, (cJSON_GetObjectItem(json_value, "wds")?cJSON_GetObjectItem(json_value, "wds")->valuestring:""));
			strcpy(stWifiIface.Ifname, (cJSON_GetObjectItem(json_value, "ifname")?cJSON_GetObjectItem(json_value, "ifname")->valuestring:""));
			strcpy(stWifiIface.Hidden, (cJSON_GetObjectItem(json_value, "hidden")?cJSON_GetObjectItem(json_value, "hidden")->valuestring:""));
			(void)WifiUciEdit(&stWifiDevice, &stWifiIface, index);
			break;

		case WIFIGET:
			pstWifiIface = WifiInfoGet(&tablenum);
			if(NULL != pstWifiIface)
			{
				cJSON_AddItemToObject(json_value,"list",array=cJSON_CreateArray());
				for(index =0; index < tablenum; index++)
				{
					cJSON_AddItemToArray(array,obj=cJSON_CreateObject());
					cJSON_AddItemToObject(obj,"mode",cJSON_CreateString(pstWifiIface->Mode));
					cJSON_AddItemToObject(obj,"ssid",cJSON_CreateString(pstWifiIface->Ssid));
					cJSON_AddItemToObject(obj,"encryption",cJSON_CreateString(pstWifiIface->Encryption));
					cJSON_AddItemToObject(obj,"key",cJSON_CreateString(pstWifiIface->Key));
					pstWifiIface++;
				}
			}
			free(pstWifiIface);
			pstWifiIface = NULL;
			break;

		default:
			break;
	
	}
	
	return ;	
}
#endif


void ProcRouterDiscovery(cJSON *jsonValue, cJSON *jsonOut)
{
	struct systemInfo output = {0};
	cJSON *obj = NULL;
	cJSON *encryptinfo = NULL;
	char *source;


	obj = cJSON_CreateObject();
	encryptinfo = cJSON_CreateObject();
	if(NULL == obj)
	{
		return;
	}
	
	(void)getSystemInfo(&output);
	cJSON_AddItemToObject(encryptinfo, "data", obj);
	cJSON_AddItemToObject(obj, "hostname", cJSON_CreateString(output.product));
	cJSON_AddItemToObject(obj, "version", cJSON_CreateString(output.productVersion));
	cJSON_AddItemToObject(obj, "serialnum", cJSON_CreateString(output.serialnum));
	cJSON_AddItemToObject(obj, "devmodel", cJSON_CreateString("mt7621a"));
	cJSON_AddItemToObject(obj, "configured", cJSON_CreateNumber(output.configured));
	cJSON_AddItemToObject(encryptinfo, "msg", cJSON_CreateString("ok"));
	cJSON_AddItemToObject(encryptinfo, "code", cJSON_CreateNumber(0));
	
	source = cJSON_Print(encryptinfo);
	cJSON_AddItemToObject(jsonOut, "encryptinfo", cJSON_CreateString(source));
	cJSON_AddItemToObject(jsonOut, "encryption", cJSON_CreateNumber(0));
	cJSON_AddItemToObject(jsonOut, "userid", cJSON_CreateNumber(0));
	cJSON_AddItemToObject(jsonOut, "keyid", cJSON_CreateString(""));
	free(source);
	
	return;
}

void ProcRouterAdd(cJSON *jsonValue, cJSON *jsonOut)
{
	char password[64] = {0};
	char passwordStore[64] = {0};
	char userbound[64] = {0};
	char staMac[64] = {0};
	char staName[64] = {0};
	char staSysInfo[64] = {0};
	char userName[64] = {0};
	char linebuffer[64] = {0};
	char buf[64] = {0};
	int  len = 0;
	int  linelen = 0;
	cJSON *obj = NULL;
	cJSON *encryptinfo = NULL;
	char *source;
	FILE *fp1 = NULL;
	FILE *fp2 = NULL;

	obj = cJSON_CreateObject();
	encryptinfo = cJSON_CreateObject();
	if(NULL == obj)
	{
		return;
	}

#if 0
	//user bound check
	fp1 = fopen("/etc/info/user_info", "r+");
	while(NULL != fgets(linebuffer, 64, fp1))
	{
		if(0 == strncmp(linebuffer, "USERBOUND", strlen("USERBUND")))
		{
			sscanf(linebuffer, "USERBOUND:%s", userbound);
			break;
		}			
	}
	fclose(fp1);
	if(0 == strcmp(userbound, "1"))
	{
		//json output data
		cJSON_AddItemToObject(jsonOut, "data", obj);
		cJSON_AddItemToObject(jsonOut, "msg", cJSON_CreateString("rounter is bound already"));
		cJSON_AddItemToObject(jsonOut, "code", cJSON_CreateNumber(1));	
		return;
	}
#endif

	//password check
	fp2 = fopen("/html/www/lighttpd.user", "r");
	fgets(buf,64,fp2);
	sscanf(buf,"admin:%s", passwordStore);
	strcpy(password, (cJSON_GetObjectItem(jsonValue, "password")?cJSON_GetObjectItem(jsonValue, "password")->valuestring:""));
	fclose(fp2);
	if(strncmp(password,passwordStore,strlen(password)) != 0)
	{
		cJSON_AddItemToObject(jsonOut, "data", obj);
		cJSON_AddItemToObject(jsonOut, "msg", cJSON_CreateString("password error!"));
		cJSON_AddItemToObject(jsonOut, "code", cJSON_CreateNumber(1));
		return;
	}

	//get sta info
	strcpy(staMac, (cJSON_GetObjectItem(jsonValue, "stamac")?cJSON_GetObjectItem(jsonValue, "stamac")->valuestring:""));
	strcpy(staName, (cJSON_GetObjectItem(jsonValue, "staname")?cJSON_GetObjectItem(jsonValue, "staname")->valuestring:""));
	strcpy(staSysInfo, (cJSON_GetObjectItem(jsonValue, "stasysinfo")?cJSON_GetObjectItem(jsonValue, "stasysinfo")->valuestring:""));
	strcpy(userName, (cJSON_GetObjectItem(jsonValue, "username")?cJSON_GetObjectItem(jsonValue, "username")->valuestring:""));

	//save stainfo
	fp1 = NULL;
	fp1 = fopen("/etc/info/user_info", "w+");
	if(NULL == fp1)
	{
		printf("open file failed");
		return;
	}

	snprintf(linebuffer, 64, "STAMAC:%s\n",staMac);
	fprintf(fp1, "%s", linebuffer);
	snprintf(linebuffer, 64, "STANAME:%s\n",staName);
	fprintf(fp1, "%s", linebuffer);
	snprintf(linebuffer, 64, "STASYSINFO:%s\n",staSysInfo);
	fprintf(fp1, "%s", linebuffer);
	snprintf(linebuffer, 64, "USERNAME:%s\n",userName);
	fprintf(fp1, "%s", linebuffer);
	snprintf(linebuffer, 64, "USERBOUND:1\n");
	fprintf(fp1, "%s", linebuffer);

	//json output data
	cJSON_AddItemToObject(encryptinfo, "data", obj);
	cJSON_AddItemToObject(encryptinfo, "msg", cJSON_CreateString("ok"));
	cJSON_AddItemToObject(encryptinfo, "code", cJSON_CreateNumber(0));

	source = cJSON_Print(encryptinfo);
	cJSON_AddItemToObject(jsonOut, "encryptinfo", cJSON_CreateString(source));
	cJSON_AddItemToObject(jsonOut, "encryption", cJSON_CreateNumber(0));
	cJSON_AddItemToObject(jsonOut, "userid", cJSON_CreateNumber(0));
	cJSON_AddItemToObject(jsonOut, "keyid", cJSON_CreateString(""));
	free(source);

	return;
}


void ProcRouterStatus(cJSON *jsonValue, cJSON *jsonOut, long userid, char *deviceid)
{
	int index = 0; 
    	struct lanHostEntry *lanHost = NULL;
	struct lanHostEntry *p = NULL;
    	int hostNum = 0;
	cJSON *subJson = NULL;
	cJSON *obj = NULL;
	cJSON *array = NULL;
	cJSON *encryptinfo = NULL;
	char *source, *dest;
	int sourcelen, destlen;
	char keyid[16] = {0};
	char key[16] = {0};
	char sourcebuffer[1024] = {0};
	char outputdata[2048] = {0};
	struct tagCQtQkMangent *pstcqtqkmangent;
	struct tagCQtKeyEncrypt *pstcqtkeyencrypt;

	pstcqtqkmangent = GetCQtQkMangent();
	pstcqtkeyencrypt = GetCQtKeyEncrypt();


	subJson = cJSON_CreateObject();
	encryptinfo = cJSON_CreateObject();
	if(NULL == subJson)
	{
		return;
	}
	
	lanHostMainLogic();
	lanHost = outputAllLanHostInfo(&hostNum);
	p = lanHost;
	cJSON_AddItemToObject(encryptinfo, "data", subJson);
	cJSON_AddItemToObject(subJson,"routerspeed",cJSON_CreateString("100kb/s"));
	if(NULL != p)
	{
		cJSON_AddItemToObject(subJson,"stalist",array=cJSON_CreateArray());
		for(index = 0; index < hostNum; index++)
		{
			cJSON_AddItemToArray(array,obj=cJSON_CreateObject());
			cJSON_AddItemToObject(obj,"staname",cJSON_CreateString(lanHost->hostname));
			if(lanHost->online)
			{
				cJSON_AddItemToObject(obj,"stastatus",cJSON_CreateString("10kb/s"));
			}
			else
			{
				cJSON_AddItemToObject(obj,"stastatus",cJSON_CreateString("offline"));
			}

			lanHost++;
		}
	}

	if(p)
	{
		free(p);
		p = NULL;
		lanHost = NULL;
	}

	cJSON_AddItemToObject(encryptinfo, "msg", cJSON_CreateString("ok"));
	cJSON_AddItemToObject(encryptinfo, "code", cJSON_CreateNumber(0));

	source = cJSON_Print(encryptinfo);
	//encrypt
	sourcelen = strlen(source);
	memcpy(sourcebuffer, source, sourcelen);
	C_GetKeyByNode(pstcqtqkmangent, POOL_TYPE_RAW, 1, userid, deviceid, keyid, key);

	C_EncryptOrDecrypt(pstcqtkeyencrypt, dest, &destlen, sourcebuffer, 1024, 1, key);
	//base64
	lws_b64_encode_string(dest, 1024, outputdata, 2048);	
	cJSON_AddItemToObject(jsonOut, "encryptinfo", cJSON_CreateString(outputdata));
	cJSON_AddItemToObject(jsonOut, "encryption", cJSON_CreateNumber(0));
	cJSON_AddItemToObject(jsonOut, "userid", cJSON_CreateNumber(0));
	cJSON_AddItemToObject(jsonOut, "keyid", cJSON_CreateString(""));

	ReleaseCQtKeyEncrypt(&pstcqtkeyencrypt);
	ReleaseCQtQkMangent(&pstcqtqkmangent);
	free(source);
}

#if 0
void ProcDevStatus(cJSON *jsonValue, cJSON *jsonOut)
{
	cJSON *obj = NULL;
	cJSON *array = NULL;

	cJSON_AddItemToObject(jsonOut,"data",array=cJSON_CreateArray());

	//temp method 
	cJSON_AddItemToArray(array,obj=cJSON_CreateObject());
	cJSON_AddItemToObject(obj,"devid",cJSON_CreateNumber(1));
	cJSON_AddItemToObject(obj,"devname",cJSON_CreateString("lockqtec"));
	cJSON_AddItemToObject(obj,"devstatus",cJSON_CreateString("fine"));

	cJSON_AddItemToArray(array,obj=cJSON_CreateObject());
	cJSON_AddItemToObject(obj,"devid",cJSON_CreateNumber(2));
	cJSON_AddItemToObject(obj,"devname",cJSON_CreateString("lockqtec1"));
	cJSON_AddItemToObject(obj,"devstatus",cJSON_CreateString("fine"));

	cJSON_AddItemToObject(jsonOut, "msg", cJSON_CreateString("ok"));
	cJSON_AddItemToObject(jsonOut, "code", cJSON_CreateNumber(0));		
}

void ProcDevInfo(cJSON *jsonValue, cJSON *jsonOut)
{
	cJSON *obj = NULL;
	cJSON *array = NULL;
	int index = 0;

	//get lock id
	index = cJSON_GetObjectItem(jsonValue, "devid")?cJSON_GetObjectItem(jsonValue, "devid")->valueint:0;

	obj = cJSON_CreateObject();
	cJSON_AddItemToObject(jsonOut, "data", obj);
	cJSON_AddItemToObject(obj,"devname",cJSON_CreateString("qtec"));
	cJSON_AddItemToObject(obj,"devgroup",cJSON_CreateString("lock"));
	cJSON_AddItemToObject(obj,"devstatus",cJSON_CreateString("fine"));

	cJSON_AddItemToObject(jsonOut, "msg", cJSON_CreateString("ok"));
	cJSON_AddItemToObject(jsonOut, "code", cJSON_CreateNumber(0));		
}

void ProcdevUnbound(cJSON *jsonValue, cJSON *jsonOut)
{
	cJSON *obj = NULL;
	cJSON *array = NULL;
	int index = 0;

	//get lock id
	index = cJSON_GetObjectItem(jsonValue, "devid")?cJSON_GetObjectItem(jsonValue, "devid")->valueint:0;

	obj = cJSON_CreateObject();
	cJSON_AddItemToObject(jsonOut, "data", obj);

	cJSON_AddItemToObject(jsonOut, "msg", cJSON_CreateString("ok"));
	cJSON_AddItemToObject(jsonOut, "code", cJSON_CreateNumber(0));		
}
#endif

void ProcdevSearch(cJSON *jsonValue, cJSON *jsonOut, long userid, char *deviceid)
{
	int index = 0;
	int devnum = 0;	
	cJSON *obj = NULL;
	cJSON *array = NULL;
	cJSON *encryptinfo = NULL;
	struct devInfo stDevInfo[10] = {0};
	char *source, *dest;
	int sourcelen, destlen;
	char keyid[16] = {0};
	char key[16] = {0};
	char sourcebuffer[1024] = {0};
	char outputdata[2048] = {0};
	struct tagCQtQkMangent *pstcqtqkmangent;
	struct tagCQtKeyEncrypt *pstcqtkeyencrypt;

	pstcqtqkmangent = GetCQtQkMangent();
	pstcqtkeyencrypt = GetCQtKeyEncrypt();

	devnum = searchDevList(stDevInfo);
	
	encryptinfo = cJSON_CreateObject();
	cJSON_AddItemToObject(encryptinfo,"data",array=cJSON_CreateArray());

	for(index = 0; index < devnum; index++)
	{
		cJSON_AddItemToArray(array,obj=cJSON_CreateObject());
		cJSON_AddItemToObject(obj,"devid",cJSON_CreateNumber(stDevInfo[index].id));
		cJSON_AddItemToObject(obj,"devname",cJSON_CreateString(stDevInfo[index].name));
	}
		

	cJSON_AddItemToObject(encryptinfo, "msg", cJSON_CreateString("ok"));
	cJSON_AddItemToObject(encryptinfo, "code", cJSON_CreateNumber(0));

	source = cJSON_Print(encryptinfo);
	//encrypt
	sourcelen = strlen(source);
	memcpy(sourcebuffer, source, sourcelen);
	C_GetKeyByNode(pstcqtqkmangent, POOL_TYPE_RAW, 1, userid, deviceid, keyid, key);

	C_EncryptOrDecrypt(pstcqtkeyencrypt, dest, &destlen, sourcebuffer, 1024, 1, key);
	//base64
	lws_b64_encode_string(dest, 1024, outputdata, 2048);
	cJSON_AddItemToObject(jsonOut, "encryptinfo", cJSON_CreateString(outputdata));
	cJSON_AddItemToObject(jsonOut, "encryption", cJSON_CreateNumber(0));
	cJSON_AddItemToObject(jsonOut, "userid", cJSON_CreateNumber(0));
	cJSON_AddItemToObject(jsonOut, "keyid", cJSON_CreateString(""));

	ReleaseCQtKeyEncrypt(&pstcqtkeyencrypt);
	ReleaseCQtQkMangent(&pstcqtqkmangent);
	free(source);		
}

void ProcDevAdd(cJSON *jsonValue, cJSON *jsonOut, long userid, char *deviceid)
{
	char password[64] = {0};
	char passwordStore[64] = {0};
	char userName[64] = {0};
	char mac[64] = {0};
	char buf[64] = {0};
	char keyid[16] = {0};
	char key[16] = {0};
	char* devId = NULL;
	char *source, *dest;
	int sourcelen, destlen;
	cJSON *obj = NULL;
	cJSON *encryptinfo = NULL;
	FILE *fp = NULL;
	char sourcebuffer[1024] = {0};
	char outputdata[2048] = {0};
	struct tagCQtQkMangent *pstcqtqkmangent;
	struct tagCQtKeyEncrypt *pstcqtkeyencrypt;

	pstcqtqkmangent = GetCQtQkMangent();
	pstcqtkeyencrypt = GetCQtKeyEncrypt();

	obj = cJSON_CreateObject();
	encryptinfo = cJSON_CreateObject();
	if(NULL == obj)
	{
		return;
	}

	//get info
	strcpy(password, (cJSON_GetObjectItem(jsonValue, "password")?cJSON_GetObjectItem(jsonValue, "password")->valuestring:""));
	strcpy(userName, (cJSON_GetObjectItem(jsonValue, "username")?cJSON_GetObjectItem(jsonValue, "username")->valuestring:""));
	strcpy(mac, (cJSON_GetObjectItem(jsonValue, "mac")?cJSON_GetObjectItem(jsonValue, "mac")->valuestring:""));
	devId = cJSON_GetObjectItem(jsonValue, "devid")?cJSON_GetObjectItem(jsonValue, "devid")->valuestring:"0";

	//json output data
	cJSON_AddItemToObject(jsonOut, "data", obj);
	fp = fopen("/html/www/lighttpd.user", "r");
	fgets(buf,64,fp);
	sscanf(buf,"admin:%s", passwordStore);
	if(strncmp(password,passwordStore,strlen(password))==0)
	{
		(void)addBandDev(atoi(devId));
		system("ubus call mywebsocket updatedevinfo");
		cJSON_AddItemToObject(encryptinfo, "msg", cJSON_CreateString("ok"));
		cJSON_AddItemToObject(encryptinfo, "code", cJSON_CreateNumber(0));
	}
	else
	{
		cJSON_AddItemToObject(encryptinfo, "msg", cJSON_CreateString("password error!"));
		cJSON_AddItemToObject(encryptinfo, "code", cJSON_CreateNumber(1));
	}

	source = cJSON_Print(encryptinfo);
	//encrypt
	sourcelen = strlen(source);
	memcpy(sourcebuffer, source, sourcelen);
	C_GetKeyByNode(pstcqtqkmangent, POOL_TYPE_RAW, 1, userid, deviceid, keyid, key);

	C_EncryptOrDecrypt(pstcqtkeyencrypt, dest, &destlen, sourcebuffer, 1024, 1, key);
	//base64
	lws_b64_encode_string(dest, 1024, outputdata, 2048);
	cJSON_AddItemToObject(jsonOut, "encryptinfo", cJSON_CreateString(outputdata));
	cJSON_AddItemToObject(jsonOut, "encryption", cJSON_CreateNumber(0));
	cJSON_AddItemToObject(jsonOut, "userid", cJSON_CreateNumber(0));
	cJSON_AddItemToObject(jsonOut, "keyid", cJSON_CreateString(""));

	ReleaseCQtKeyEncrypt(&pstcqtkeyencrypt);
	ReleaseCQtQkMangent(&pstcqtqkmangent);
	free(source);	
}

void ProcFirstKeyReq(cJSON *jsonValue, cJSON *jsonOut, long userid, char *deviceid)
{

	printf("enter ProcFirstKeyReq.\r\n");

	char devicename[16] = {0};
	char keyid[17] = {0};
	char key[17] = {0};
	SrcMessage stSrcMessage = {0};
	DestMessage stDestMessage = {0};
	RemoteInfo stRemoteInfo = {0};
	int destlen = 0;
	int sourcelen = 0;
	int originlen = 0;
	int usedcount = 0;
	int unusedcount = 0;
	int index;
	char *source, *keytemp, *keyidtemp;
	char *dest, *sourcebuffer, *outputdata;
	char origin[4096] = {0};
	cJSON *encryptinfo = NULL;
	cJSON *data = NULL;
	cJSON *obj = NULL;
	cJSON *array = NULL;
	struct tagCQtQkMangent *pstcqtqkmangent;
	struct tagCQtKeyEncrypt *pstcqtkeyencrypt;

	pstcqtqkmangent = GetCQtQkMangent();
	pstcqtkeyencrypt = GetCQtKeyEncrypt();

	stDestMessage.keyId = malloc(1024);
	stDestMessage.key = malloc(1024);
	dest = malloc(4096);
	sourcebuffer = malloc(4096); 
	outputdata = malloc(8192);
	memset(stDestMessage.keyId, 0, 1024);
	memset(stDestMessage.keyId, 0, 1024);
	memset(dest, 0, 4096);
	memset(sourcebuffer, 0, 4096);
	memset(outputdata, 0, 8192);

	data = cJSON_CreateObject();
	encryptinfo = cJSON_CreateObject();
	
	//get info
	stSrcMessage.mesType = 101;
	stSrcMessage.reqId = cJSON_GetObjectItem(jsonValue, "requestid")?cJSON_GetObjectItem(jsonValue, "requestid")->valueint:1; 
	stSrcMessage.keyType = cJSON_GetObjectItem(jsonValue, "keytype")?cJSON_GetObjectItem(jsonValue, "keytype")->valueint:0; 
	stSrcMessage.keyNumber = cJSON_GetObjectItem(jsonValue, "keynumber")?cJSON_GetObjectItem(jsonValue, "keynumber")->valueint:4; 
	stSrcMessage.keyLength = 16;
	stSrcMessage.specified = 1;
	stSrcMessage.shareNumber = 1;
	stSrcMessage.localUserId = userid;
	strcpy(stSrcMessage.localDeviceId, deviceid);
	strcpy(devicename, (cJSON_GetObjectItem(jsonValue, "devicename")?cJSON_GetObjectItem(jsonValue, "devicename")->valuestring:""));
	stRemoteInfo.remoteUserId = 23;
	strcpy(stRemoteInfo.remoteDevicedId, "2");

	printf("requestid is:%d, keytype is:%d, keynumber is:%d", stSrcMessage.reqId, stSrcMessage.keyType, stSrcMessage.keyNumber);
	
	//if rawkeynumber <5, addkey
	C_GetCount(pstcqtqkmangent, POOL_TYPE_RAW, &usedcount, &unusedcount, userid, deviceid);
	if(unusedcount <= 5)
	{
		AddRawKey(userid);
		printf("first usedcount:%d, unusedcount:%d.\r\n", usedcount, unusedcount);
	}

	C_GetCount(pstcqtqkmangent, POOL_TYPE_RAW, &usedcount, &unusedcount, userid, deviceid);
	printf("second usedcount:%d, unusedcount:%d.\r\n", usedcount, unusedcount);

	C_GetCount(pstcqtqkmangent, POOL_TYPE_SYNC, &usedcount, &unusedcount, userid, deviceid);
	printf("first synckey usedcount:%d, unusedcount:%d.\r\n", usedcount, unusedcount);
	//get synkey
	C_DealClientSynReq(&stDestMessage, &stSrcMessage);

	C_GetCount(pstcqtqkmangent, POOL_TYPE_SYNC, &usedcount, &unusedcount, userid, deviceid);
	printf("second synckey usedcount:%d, unusedcount:%d.\r\n", usedcount, unusedcount);

	C_GetCount(pstcqtqkmangent, POOL_TYPE_RAW, &usedcount, &unusedcount, userid, deviceid);
	printf("third usedcount:%d, unusedcount:%d.\r\n", usedcount, unusedcount);

	//jsonout
	cJSON_AddItemToObject(data, "keytype", cJSON_CreateNumber(stDestMessage.keyType));
	cJSON_AddItemToObject(data, "keynumber", cJSON_CreateNumber(stDestMessage.keyNumber));
	cJSON_AddItemToObject(data, "requestid", cJSON_CreateNumber(stDestMessage.reqId));
	cJSON_AddItemToObject(data, "deviceid", cJSON_CreateString(stDestMessage.pushDeviceId));
	cJSON_AddItemToObject(data, "devicename", cJSON_CreateString(devicename));
	cJSON_AddItemToObject(data,"keylist",array=cJSON_CreateArray());

	keytemp = stDestMessage.key;
	keyidtemp = stDestMessage.keyId;
	for(index = 0; index < stSrcMessage.keyNumber; index++)
	{
		memset(keyid, 0 ,17);
		memset(key, 0 ,17);
		memcpy(keyid, keyidtemp, 16);
		memcpy(key, keytemp, 16);
		cJSON_AddItemToArray(array,obj=cJSON_CreateObject());
		cJSON_AddItemToObject(obj,"keyid",cJSON_CreateString(keyid));
		cJSON_AddItemToObject(obj,"key",cJSON_CreateString(key));
		keytemp += 16;
		keyidtemp += 16;
	}
	cJSON_AddItemToObject(encryptinfo, "data", data);

	cJSON_AddItemToObject(encryptinfo, "msg", cJSON_CreateString("ok"));
	cJSON_AddItemToObject(encryptinfo, "code", cJSON_CreateNumber(0));
		
	source = cJSON_PrintUnformatted(encryptinfo);
	sourcelen = strlen(source);
	memcpy(sourcebuffer, source, sourcelen);

	//encrypt
	printf("output is %s.\r\n", source);
	memset(keyid, 0 ,16);
	memset(key, 0 ,16);
	C_GetKeyByNode(pstcqtqkmangent, POOL_TYPE_RAW, 1, userid, deviceid, keyid, key);
	printf("key is:%s.\r\n", key);

	C_EncryptOrDecrypt(pstcqtkeyencrypt, dest, &destlen, sourcebuffer, 4096, 1, key);
	//base64
	lws_b64_encode_string(dest, 4096, outputdata, 8192);
	
	C_EncryptOrDecrypt(pstcqtkeyencrypt, origin, &originlen, dest, 4096, 0, key);
	printf("dest is %s.\r\n", dest);
	printf("origin is %s.\r\n", origin);
	printf("sourcelen:%d,destlen:%d,originlen:%d.\r\n",sourcelen,strlen(dest),strlen(origin));
		
	cJSON_AddItemToObject(jsonOut, "encryptinfo", cJSON_CreateString(outputdata));
	cJSON_AddItemToObject(jsonOut, "encryption", cJSON_CreateNumber(0));
	cJSON_AddItemToObject(jsonOut, "userid", cJSON_CreateNumber(0));
	cJSON_AddItemToObject(jsonOut, "keyid", cJSON_CreateString(""));
	
	ReleaseCQtKeyEncrypt(&pstcqtkeyencrypt);
	ReleaseCQtQkMangent(&pstcqtqkmangent);
	free(source);
	free(sourcebuffer);
	free(dest);
	free(outputdata);
	free(stDestMessage.keyId);
	free(stDestMessage.key);

	return;	
}

void ProcKeyReq(cJSON *jsonValue, cJSON *jsonOut, long userid, char *deviceid)
{

	printf("enter ProcFirstKeyReq.\r\n");

	char devicename[16] = {0};
	char keyid[17] = {0};
	char key[17] = {0};
	SrcMessage stSrcMessage = {0};
	DestMessage stDestMessage = {0};
	RemoteInfo stRemoteInfo = {0};
	int destlen = 0;
	int sourcelen = 0;
	int originlen = 0;
	int usedcount = 0;
	int unusedcount = 0;
	int index;
	char *source, *keytemp, *keyidtemp;
	char *dest, *sourcebuffer, *outputdata;
	char origin[4096] = {0};
	cJSON *encryptinfo = NULL;
	cJSON *data = NULL;
	cJSON *obj = NULL;
	cJSON *array = NULL;
	struct tagCQtQkMangent *pstcqtqkmangent;
	struct tagCQtKeyEncrypt *pstcqtkeyencrypt;

	pstcqtqkmangent = GetCQtQkMangent();
	pstcqtkeyencrypt = GetCQtKeyEncrypt();

	stDestMessage.keyId = malloc(1024);
	stDestMessage.key = malloc(1024);
	dest = malloc(4096);
	sourcebuffer = malloc(4096); 
	outputdata = malloc(8192);
	memset(stDestMessage.keyId, 0, 1024);
	memset(stDestMessage.keyId, 0, 1024);
	memset(dest, 0, 4096);
	memset(sourcebuffer, 0, 4096);
	memset(outputdata, 0, 8192);

	data = cJSON_CreateObject();
	encryptinfo = cJSON_CreateObject();
	
	//get info
	stSrcMessage.mesType = 101;
	stSrcMessage.reqId = cJSON_GetObjectItem(jsonValue, "requestid")?cJSON_GetObjectItem(jsonValue, "requestid")->valueint:1; 
	stSrcMessage.keyType = cJSON_GetObjectItem(jsonValue, "keytype")?cJSON_GetObjectItem(jsonValue, "keytype")->valueint:0; 
	stSrcMessage.keyNumber = cJSON_GetObjectItem(jsonValue, "keynumber")?cJSON_GetObjectItem(jsonValue, "keynumber")->valueint:4; 
	stSrcMessage.keyLength = 16;
	stSrcMessage.specified = 1;
	stSrcMessage.shareNumber = 1;
	stSrcMessage.localUserId = userid;
	strcpy(stSrcMessage.localDeviceId, deviceid);
	strcpy(devicename, (cJSON_GetObjectItem(jsonValue, "devicename")?cJSON_GetObjectItem(jsonValue, "devicename")->valuestring:""));
	stRemoteInfo.remoteUserId = 23;
	strcpy(stRemoteInfo.remoteDevicedId, "2");

	printf("requestid is:%d, keytype is:%d, keynumber is:%d", stSrcMessage.reqId, stSrcMessage.keyType, stSrcMessage.keyNumber);
	
	//if rawkeynumber <5, addkey
	C_GetCount(pstcqtqkmangent, POOL_TYPE_RAW, &usedcount, &unusedcount, userid, deviceid);
	if(unusedcount <= 5)
	{
		AddRawKey(userid);
		printf("first usedcount:%d, unusedcount:%d.\r\n", usedcount, unusedcount);
	}

	C_GetCount(pstcqtqkmangent, POOL_TYPE_RAW, &usedcount, &unusedcount, userid, deviceid);
	printf("second usedcount:%d, unusedcount:%d.\r\n", usedcount, unusedcount);

	//get synkey
	C_DealClientSynReq(&stDestMessage, &stSrcMessage);

	C_GetCount(pstcqtqkmangent, POOL_TYPE_RAW, &usedcount, &unusedcount, userid, deviceid);
	printf("third usedcount:%d, unusedcount:%d.\r\n", usedcount, unusedcount);

	//jsonout
	cJSON_AddItemToObject(data, "keytype", cJSON_CreateNumber(stDestMessage.keyType));
	cJSON_AddItemToObject(data, "keynumber", cJSON_CreateNumber(stDestMessage.keyNumber));
	cJSON_AddItemToObject(data, "requestid", cJSON_CreateNumber(stDestMessage.reqId));
	cJSON_AddItemToObject(data, "deviceid", cJSON_CreateString(stDestMessage.pushDeviceId));
	cJSON_AddItemToObject(data, "devicename", cJSON_CreateString(devicename));
	cJSON_AddItemToObject(data,"keylist",array=cJSON_CreateArray());

	keytemp = stDestMessage.key;
	keyidtemp = stDestMessage.keyId;
	for(index = 0; index < stSrcMessage.keyNumber; index++)
	{
		memset(keyid, 0 ,17);
		memset(key, 0 ,17);
		memcpy(keyid, keyidtemp, 16);
		memcpy(key, keytemp, 16);
		cJSON_AddItemToArray(array,obj=cJSON_CreateObject());
		cJSON_AddItemToObject(obj,"keyid",cJSON_CreateString(keyid));
		cJSON_AddItemToObject(obj,"key",cJSON_CreateString(key));
		keytemp += 16;
		keyidtemp += 16;
	}
	cJSON_AddItemToObject(encryptinfo, "data", data);

	cJSON_AddItemToObject(encryptinfo, "msg", cJSON_CreateString("ok"));
	cJSON_AddItemToObject(encryptinfo, "code", cJSON_CreateNumber(0));
		
	source = cJSON_PrintUnformatted(encryptinfo);
	sourcelen = strlen(source);
	memcpy(sourcebuffer, source, sourcelen);

	//encrypt
	printf("output is %s.\r\n", source);
	memset(keyid, 0 ,16);
	memset(key, 0 ,16);
	C_GetKeyByNode(pstcqtqkmangent, POOL_TYPE_SYNC, 1, userid, deviceid, keyid, key);
	printf("key is:%s.\r\n", key);

	C_EncryptOrDecrypt(pstcqtkeyencrypt, dest, &destlen, sourcebuffer, 4096, 1, key);
	//base64
	lws_b64_encode_string(dest, 4096, outputdata, 8192);
	
	C_EncryptOrDecrypt(pstcqtkeyencrypt, origin, &originlen, dest, 4096, 0, key);
	printf("dest is %s.\r\n", dest);
	printf("origin is %s.\r\n", origin);
	printf("sourcelen:%d,destlen:%d,originlen:%d.\r\n",sourcelen,strlen(dest),strlen(origin));
		
	cJSON_AddItemToObject(jsonOut, "encryptinfo", cJSON_CreateString(outputdata));
	cJSON_AddItemToObject(jsonOut, "encryption", cJSON_CreateNumber(0));
	cJSON_AddItemToObject(jsonOut, "userid", cJSON_CreateNumber(0));
	cJSON_AddItemToObject(jsonOut, "keyid", cJSON_CreateString(keyid));
	
	ReleaseCQtKeyEncrypt(&pstcqtkeyencrypt);
	ReleaseCQtQkMangent(&pstcqtqkmangent);
	free(source);
	free(sourcebuffer);
	free(dest);
	free(outputdata);

	return;	
}


void decode_message(char *msg)
{
	cJSON *json, *jsonValue, *jsonOut, *encryptinfo;
	char *target, *buffer, *dest, *keyid, *deviceid;
	int method, f0, f1, f2, sourcelen, destlen, encryption;
	long userid;
	struct tagCQtQkMangent *pstcqtqkmangent;
	struct tagCQtKeyEncrypt *pstcqtkeyencrypt;
	char key[16] = {0};
	char origin[1024] = {0};
	char source[1024] = {0};
	
	json = cJSON_Parse(msg);
	if (!json)
	{
		printf("error!");
		return;		
	}
	
	f0 = dup(STDOUT_FILENO);
	f1 = open("/etc/info/huangkai", O_RDWR);
	f2 = dup2(f1, STDOUT_FILENO);
	close(f1);
	
	pstcqtqkmangent = GetCQtQkMangent();
	pstcqtkeyencrypt = GetCQtKeyEncrypt();  
	dest = cJSON_GetObjectItem(json, "encryptinfo")?cJSON_GetObjectItem(json, "encryptinfo")->valuestring:"";
	keyid = cJSON_GetObjectItem(json, "keyid")?cJSON_GetObjectItem(json, "keyid")->valuestring:"";
	deviceid = cJSON_GetObjectItem(json, "deviceid")?cJSON_GetObjectItem(json, "deviceid")->valuestring:"";
	encryption = cJSON_GetObjectItem(json, "encryption")?cJSON_GetObjectItem(json, "encryption")->valueint:0;
	userid = cJSON_GetObjectItem(json, "userid")?cJSON_GetObjectItem(json, "userid")->valueint:0;

	destlen = sizeof(dest);

	printf("userid is %d,deviceid is %s.\r\n", userid, deviceid);
	printf("dest is :%s\r\n", dest);
	if(encryption)
	{
		//decrypt
		//base64 
		lws_b64_decode_string(dest, origin, 1024);
		//get key
		C_GetKeyByIdNode(pstcqtqkmangent, POOL_TYPE_SYNC, 1, userid, deviceid, keyid, key);
		C_DeleteKeyById(pstcqtqkmangent, 1, POOL_TYPE_SYNC, keyid);
		C_EncryptOrDecrypt(pstcqtkeyencrypt, source, &sourcelen, origin, 1024, 0, key);
		printf("source is :%s\r\n", source);
		encryptinfo = cJSON_Parse(source);
		target = cJSON_GetObjectItem(encryptinfo, "requestUrl")?cJSON_GetObjectItem(encryptinfo, "requestUrl")->valuestring:"";
		jsonValue = cJSON_GetObjectItem(encryptinfo, "data");
	}
	else
	{
		encryptinfo = cJSON_Parse(dest);
		target = cJSON_GetObjectItem(encryptinfo, "requestUrl")?cJSON_GetObjectItem(encryptinfo, "requestUrl")->valuestring:"";
		jsonValue = cJSON_GetObjectItem(encryptinfo, "data");
	}
	
	printf("target is %s.\r\n", target);
	jsonOut = cJSON_CreateObject();

#if 0
	if (!strcmp(target,"Wancfg"))
	{
		proc_wan(json_value, method);
	}
	else if (!strcmp(target,"Wirelesscfg"))
	{
		proc_wireless(json_value, method);
	}
	else if (!strcmp(target,"Lancfg"))
	{
		proc_lan(json_value, method);
	}
	else if(!strcmp(target,"Firewallcfg"))
	{
		proc_firewall(json_value, method);
	}
	else if(!strcmp(target,"Ntpcfg"))
	{
		proc_ntp(json_value, method);
	}
#endif

	if(!strcmp(target,"routerinfo"))
	{
		ProcRouterDiscovery(jsonValue, jsonOut);
	}
	else if(!strcmp(target,"routeradd"))
	{
		ProcRouterAdd(jsonValue, jsonOut);
	}
	else if(!strcmp(target,"routerstatus"))
	{
		ProcRouterStatus(jsonValue, jsonOut, userid, deviceid);
	}
#if 0
	else if(!strcmp(target,"devlist"))
	{
		ProcDevStatus(jsonValue, jsonOut);
	}
	else if(!strcmp(target,"devinfo"))
	{
		ProcDevInfo(jsonValue, jsonOut);
	}
	else if(!strcmp(target,"devunbound"))
	{
		ProcdevUnbound(jsonValue, jsonOut);
	}
#endif
	else if(!strcmp(target,"devsearch"))
	{
		ProcdevSearch(jsonValue, jsonOut, userid, deviceid);
	}
	else if(!strcmp(target,"devadd"))
	{
		ProcDevAdd(jsonValue, jsonOut, userid, deviceid);
	}
	else if(!strcmp(target,"firstkeyrequest"))
	{
		ProcFirstKeyReq(jsonValue, jsonOut, userid, deviceid);
	}
	else if(!strcmp(target,"keyrequest"))
	{
		ProcKeyReq(jsonValue, jsonOut, userid, deviceid);
	}

	fflush(stdout);
	ReleaseCQtKeyEncrypt(&pstcqtkeyencrypt);
	ReleaseCQtQkMangent(&pstcqtqkmangent);  
	dup2(f0, f2);
	buffer = cJSON_Print(jsonOut);
	printf("%s\n",buffer);
	free(buffer);

	cJSON_Delete(jsonOut);
	cJSON_Delete(json);
	cJSON_Delete(encryptinfo);
	
	return;
}

int main()
{
	int length;
	char *method;
	char *inputstring;
	
	printf("content-type:application/json\r\n\r\n");
	fflush(stdout);

	method = getenv("REQUEST_METHOD"); 
	if(method == NULL)
	{
		return 1;   
	}
	
	//post method,read from stdin
	if(!strcmp(method, "POST")) 
	{

		length = atoi(getenv("CONTENT_LENGTH")); 
		if(length != 0)
		{
			inputstring = malloc(sizeof(char)*length + 1); 
			if (0 != fread(inputstring, sizeof(char), length, stdin)) 
			{
				decode_message(inputstring);
			}
	    }
	}

	//get method
	else if(!strcmp(method, "GET"))
	{

		inputstring = getenv("QUERY_STRING");   
		length = strlen(inputstring);

	}

	return 0;
}

