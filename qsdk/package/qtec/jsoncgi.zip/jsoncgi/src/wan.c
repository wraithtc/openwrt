#include "basic.h"

//����ļ�����wan��ص�����
void proc_wan_set(cJSON *json_value, cJSON *jsonOut)
{
    DEBUG_PRINTF("====[%s]====%d===\n",__func__,__LINE__);
	struct wanStaticConfig wannode = {0};
	struct wanPppoeConfig  pppoeNode = {0};
	int ret=0;
    char *type=NULL;
    type = cJSON_GetObjectItem(json_value, "connectiontype")?cJSON_GetObjectItem(json_value, "connectiontype")->valuestring:"";

    if(strncmp(type,"dhcp",strlen(type))==0)
    {
		ret=wanDhcpConfigSet();
    }
    else if(strncmp(type,"pppoe",strlen(type))==0)
    {
		strcpy(pppoeNode.username, (cJSON_GetObjectItem(json_value, "username")?cJSON_GetObjectItem(json_value, "username")->valuestring:""));

#if 0
        //��pppoe �������base64 �������
        char tmp_base64_password[64]={0};
		//strcpy(pppoeNode.password, (cJSON_GetObjectItem(json_value, "password")?cJSON_GetObjectItem(json_value, "password")->valuestring:""));
	    strcpy(tmp_base64_password,(cJSON_GetObjectItem(json_value, "password")?cJSON_GetObjectItem(json_value, "password")->valuestring:""));
        DEBUG_PRINTF("[%s]====tmp_base64_password: %s====\n",__func__,tmp_base64_password);
        base64_decode(tmp_base64_password, pppoeNode.password);  
        DEBUG_PRINTF("[%s], ppppoeNode.password: %s===\n",__func__,pppoeNode.password);
#endif
        char *password=NULL;
        password =cJSON_GetObjectItem(json_value, "password")?cJSON_GetObjectItem(json_value, "password")->valuestring:"";

        DEBUG_PRINTF("===[%s]===str: %s ===\n",__func__,password);
        unsigned char bindata[2048]={0};
        base64_decode(password, bindata);
    
        char *result=NULL;
        result=(char *)my_decrypt(bindata, RSA_PRIVATE_KEY_FILE); 
        DEBUG_PRINTF("[%s]====result %s===\n",__func__,result);
        if(result == NULL)
        {
            global_weberrorcode=ERR_DECRY_FAIL;
            return;
        }
        
        strcpy(pppoeNode.password,result);
		ret=wanPppoeConfigSet(&pppoeNode);
    }
    else if(strncmp(type,"static",strlen(type))==0)
    {
	    strcpy(wannode.ipaddr, (cJSON_GetObjectItem(json_value, "ipaddr")?cJSON_GetObjectItem(json_value, "ipaddr")->valuestring:""));
		strcpy(wannode.netmask, (cJSON_GetObjectItem(json_value, "netmask")?cJSON_GetObjectItem(json_value, "netmask")->valuestring:""));
		strcpy(wannode.gateway, (cJSON_GetObjectItem(json_value, "gateway")?cJSON_GetObjectItem(json_value, "gateway")->valuestring:""));
		strcpy(wannode.dns, (cJSON_GetObjectItem(json_value, "dns")?cJSON_GetObjectItem(json_value, "dns")->valuestring:""));
		ret=wanStaticConfigSet(&wannode);
    }
    else
    {
            global_weberrorcode=ERR_VALUE_WRONG;
	}


	return;	
}

void get_wan_type(cJSON *json_value,cJSON *jsonOut)
{
    DEBUG_PRINTF("====[%s]====%d===\n",__func__,__LINE__);
    int type=0;
    int ret=0;

    cJSON *obj = NULL;
	obj = cJSON_CreateObject();

    ret=getWanConnectionType(&type);

    if(ret != 0)
    {
        global_weberrorcode=ERR_INTERNALLOGIC_WRONG;
        return;
    }

    cJSON_AddItemToObject(jsonOut, "data", obj);

    if(type == WANDHCP)
    {
        cJSON_AddItemToObject(obj, "connectiontype", cJSON_CreateString("dhcp"));
    }
    else if(type == WANPPPOE)
    {
        cJSON_AddItemToObject(obj, "connectiontype", cJSON_CreateString("pppoe"));
    }
    else if(type == WANSTATIC)
    {
        cJSON_AddItemToObject(obj, "connectiontype", cJSON_CreateString("static"));
    }
}

void proc_wan_get(cJSON *json_value,cJSON *jsonOut)
{
    DEBUG_PRINTF("====[%s]====%d===\n",__func__,__LINE__);
    int type=0;
    int ret=0;
    
    cJSON *obj = NULL;
	obj = cJSON_CreateObject();
    
    ret=getWanConnectionType(&type);
    DEBUG_PRINTF("===[%s]===ret:%d==== type:%d====\n",__func__,ret,type);

    if(ret != 0)
    {
        cJSON_AddItemToObject(jsonOut, "code", cJSON_CreateNumber(1));	
	    cJSON_AddItemToObject(jsonOut, "msg", cJSON_CreateString("wan type get fail"));
        return;
    }

    if(type == WANDHCP)
    {
        
        cJSON_AddItemToObject(jsonOut, "data", obj);
        cJSON_AddItemToObject(obj, "connectiontype", cJSON_CreateString("dhcp"));
        cJSON_AddItemToObject(jsonOut, "code", cJSON_CreateNumber(0));	
	    cJSON_AddItemToObject(jsonOut, "msg", cJSON_CreateString("success"));
        
        return;
    }
    else if(type == WANPPPOE)
    {
         
        struct wanPppoeConfig  pppoeNode = {0};
        ret = wanPppoeConfigGet(&pppoeNode);
        
        if(ret !=0)
        {
            cJSON_AddItemToObject(jsonOut, "code", cJSON_CreateNumber(1));	
	        cJSON_AddItemToObject(jsonOut, "msg", cJSON_CreateString("pppoe get values fail"));
            return;
        }
        else
        {
            cJSON_AddItemToObject(jsonOut, "data", obj);
            cJSON_AddItemToObject(obj, "connectiontype", cJSON_CreateString("pppoe"));
           	cJSON_AddItemToObject(obj, "username", cJSON_CreateString(pppoeNode.username));
	        cJSON_AddItemToObject(obj, "password", cJSON_CreateString(pppoeNode.password));
            cJSON_AddItemToObject(jsonOut, "code", cJSON_CreateNumber(0));	
	        cJSON_AddItemToObject(jsonOut, "msg", cJSON_CreateString("success"));
        }
    }
    else if(type == WANSTATIC)
    {
       
        struct wanStaticConfig wannode = {0};
        ret = wanStaticConfigGet(&wannode);
        
        if(ret !=0)
        {
            cJSON_AddItemToObject(jsonOut, "code", cJSON_CreateNumber(1));	
	        cJSON_AddItemToObject(jsonOut, "msg", cJSON_CreateString("wan static get values fail"));
            return;
        }
        else
        {
            cJSON_AddItemToObject(jsonOut, "data", obj);
            cJSON_AddItemToObject(obj, "connectiontype", cJSON_CreateString("static"));
           	cJSON_AddItemToObject(obj, "ipaddr", cJSON_CreateString(wannode.ipaddr));
	        cJSON_AddItemToObject(obj, "netmask", cJSON_CreateString(wannode.netmask));
            cJSON_AddItemToObject(obj, "gateway", cJSON_CreateString(wannode.gateway));
            cJSON_AddItemToObject(jsonOut, "code", cJSON_CreateNumber(0));	
	        cJSON_AddItemToObject(jsonOut, "msg", cJSON_CreateString("success"));
            return;
        }
    }
    else
    {
        cJSON_AddItemToObject(jsonOut, "code", cJSON_CreateNumber(1));	
	    cJSON_AddItemToObject(jsonOut, "msg", cJSON_CreateString("wan connection type not identify"));
        return;
    }
    return;
    
}

//���wan�ܷ�����
//ubus call network.interface.wan status 

#define test_internet_ipaddress "8.8.8.8"
void proc_wan_detect(cJSON *json_value, cJSON *jsonOut)
{
    DEBUG_PRINTF("===[%s]====\n",__func__);
    int ret=0;
    FILE *file;
    char wan_up[10]={0}; //ȷ��wan�������Ƿ���ϣ�����pppoe�Ƿ����ӳɹ�
    char wan_ipaddr[64]={0}; //��ȡwan ��ip��ַ
    char wan_gw[64]={0}; //��ȡwan�� gw ��ַ
    char wan_dns[64]={0}; // ��ȡwan�� dns��ַ
    char line[256]={0};
    int type=0;
    char wan_ifname[256]={0};
    rtcfgUciGet("network.wan.ifname",wan_ifname);
    ret=getWanConnectionType(&type);
    
    if(type == WANSTATIC)
    {
        struct wanStaticConfig wannode = {0};
        ret = wanStaticConfigGet(&wannode);
        if(ret !=0)
        {
            DEBUG_PRINTF("[%s]==can't get wan static config===\n",__func__);
            global_weberrorcode=ERR_INTERNALLOGIC_WRONG;
        }

        //check wan gw
        ret=checkPingResult(wannode.gateway,wan_ifname);
        if(ret !=0)
        {
            global_weberrorcode=ERR_WAN_GWWRONG;
            return;
        }

        //��ʱ����dns
        ret=checkPingResult(test_internet_ipaddress, wan_ifname);
        if(ret !=0)
        {
            global_weberrorcode=ERR_WAN_INTERNETWRONG;
            return;
        }
        
        return;
    }
    else
    {
        file=popen("ubus call network.interface.wan status", "r");

        if( NULL != file )
        {
            while (fgets(line,sizeof(line),file) != NULL)
            {
               
                if(strstr(line,"\"up\"")!=NULL)
                {
                    DEBUG_PRINTF("line=%s \n",line);
                    
                    sscanf(line," \"up\": %s,",wan_up);
                }

                if(strstr(line, "\"address\":")!=NULL)
                {
                    DEBUG_PRINTF("line=%s \n",line);
                    sscanf(line," \"address\": %s",wan_ipaddr);
                }

                if(strstr(line, "\"nexthop\":")!=NULL)
                {
                    DEBUG_PRINTF("line=%s \n",line);
                    sscanf(line," \"nexthop\": %s",wan_gw);
                }
         
            }

            if(strncmp(wan_up,"true,",strlen(wan_up)) != 0)
            {
                global_weberrorcode = ERR_WAN_NOTUP;
                return;
            }

            if( strlen(wan_ipaddr) ==0 )
            {
                global_weberrorcode = ERR_WAN_IPWRONG;
                return;
            }

            if( strlen(wan_gw) == 0)
            {
                global_weberrorcode = ERR_WAN_GWWRONG;
                return;
            }
            else
            {
                wan_gw[strlen(wan_gw)-1]='\0';
                DEBUG_PRINTF("[%s]====wan_gw: %s=====\n",__func__,wan_gw);
                ret=checkPingResult(wan_gw, wan_ifname);
                if(ret !=0)
                {
                    global_weberrorcode= ERR_WAN_GWWRONG;
                    return;
                }

                ret =checkPingResult(test_internet_ipaddress, wan_ifname);
                if(ret !=0 )
                {
                    global_weberrorcode=ERR_WAN_INTERNETWRONG;
                    return; 
                }
            }
        }
        else
        {
            DEBUG_PRINTF("[%s]===popen fail ===\n",__func__);
            global_weberrorcode=ERR_INTERNALLOGIC_WRONG;
            return;
        }
        pclose(file);
    }

   
}
