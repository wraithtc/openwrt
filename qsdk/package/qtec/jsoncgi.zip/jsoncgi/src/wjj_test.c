#include "stdio.h"

int main()
{

	printf("Content-Type: application/json \r\n");
    printf("Access-Control-Allow-Origin: * \r\n\r\n");

    printf( "Hello world !\n");
    return 0;
}
